import { element, by, ElementFinder } from 'protractor';

export class OpportunityComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-opportunity div table .btn-danger'));
  title = element.all(by.css('jhi-opportunity div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getText();
  }
}

export class OpportunityUpdatePage {
  pageTitle = element(by.id('jhi-opportunity-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  opportunityIdInput = element(by.id('field_opportunityId'));
  accountNameInput = element(by.id('field_accountName'));
  opportunityNameInput = element(by.id('field_opportunityName'));
  typeInput = element(by.id('field_type'));
  opportunityDomainInput = element(by.id('field_opportunityDomain'));
  forecastCategoryInput = element(by.id('field_forecastCategory'));
  opportunityStageInput = element(by.id('field_opportunityStage'));
  probabilityInput = element(by.id('field_probability'));
  opportunitySizeInput = element(by.id('field_opportunitySize'));
  qualifiedDealSizeInput = element(by.id('field_qualifiedDealSize'));
  weightedDealSizeInput = element(by.id('field_weightedDealSize'));
  closeDateInput = element(by.id('field_closeDate'));
  closeFiscalQuarterInput = element(by.id('field_closeFiscalQuarter'));
  createdDateInput = element(by.id('field_createdDate'));
  createdByInput = element(by.id('field_createdBy'));
  fopsNamesInput = element(by.id('field_fopsNames'));
  partnersInput = element(by.id('field_partners'));
  competitorsNamesInput = element(by.id('field_competitorsNames'));
  opportunityOwnerInput = element(by.id('field_opportunityOwner'));
  accountOwnerInput = element(by.id('field_accountOwner'));
  sccountRVPInput = element(by.id('field_sccountRVP'));
  fiscalYearInput = element(by.id('field_fiscalYear'));
  qualifiedWinLossInput = element(by.id('field_qualifiedWinLoss'));
  opportunityShadowOfferingsInput = element(by.id('field_opportunityShadowOfferings'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getText();
  }

  async setOpportunityIdInput(opportunityId: string): Promise<void> {
    await this.opportunityIdInput.sendKeys(opportunityId);
  }

  async getOpportunityIdInput(): Promise<string> {
    return await this.opportunityIdInput.getAttribute('value');
  }

  async setAccountNameInput(accountName: string): Promise<void> {
    await this.accountNameInput.sendKeys(accountName);
  }

  async getAccountNameInput(): Promise<string> {
    return await this.accountNameInput.getAttribute('value');
  }

  async setOpportunityNameInput(opportunityName: string): Promise<void> {
    await this.opportunityNameInput.sendKeys(opportunityName);
  }

  async getOpportunityNameInput(): Promise<string> {
    return await this.opportunityNameInput.getAttribute('value');
  }

  async setTypeInput(type: string): Promise<void> {
    await this.typeInput.sendKeys(type);
  }

  async getTypeInput(): Promise<string> {
    return await this.typeInput.getAttribute('value');
  }

  async setOpportunityDomainInput(opportunityDomain: string): Promise<void> {
    await this.opportunityDomainInput.sendKeys(opportunityDomain);
  }

  async getOpportunityDomainInput(): Promise<string> {
    return await this.opportunityDomainInput.getAttribute('value');
  }

  async setForecastCategoryInput(forecastCategory: string): Promise<void> {
    await this.forecastCategoryInput.sendKeys(forecastCategory);
  }

  async getForecastCategoryInput(): Promise<string> {
    return await this.forecastCategoryInput.getAttribute('value');
  }

  async setOpportunityStageInput(opportunityStage: string): Promise<void> {
    await this.opportunityStageInput.sendKeys(opportunityStage);
  }

  async getOpportunityStageInput(): Promise<string> {
    return await this.opportunityStageInput.getAttribute('value');
  }

  async setProbabilityInput(probability: string): Promise<void> {
    await this.probabilityInput.sendKeys(probability);
  }

  async getProbabilityInput(): Promise<string> {
    return await this.probabilityInput.getAttribute('value');
  }

  async setOpportunitySizeInput(opportunitySize: string): Promise<void> {
    await this.opportunitySizeInput.sendKeys(opportunitySize);
  }

  async getOpportunitySizeInput(): Promise<string> {
    return await this.opportunitySizeInput.getAttribute('value');
  }

  async setQualifiedDealSizeInput(qualifiedDealSize: string): Promise<void> {
    await this.qualifiedDealSizeInput.sendKeys(qualifiedDealSize);
  }

  async getQualifiedDealSizeInput(): Promise<string> {
    return await this.qualifiedDealSizeInput.getAttribute('value');
  }

  async setWeightedDealSizeInput(weightedDealSize: string): Promise<void> {
    await this.weightedDealSizeInput.sendKeys(weightedDealSize);
  }

  async getWeightedDealSizeInput(): Promise<string> {
    return await this.weightedDealSizeInput.getAttribute('value');
  }

  async setCloseDateInput(closeDate: string): Promise<void> {
    await this.closeDateInput.sendKeys(closeDate);
  }

  async getCloseDateInput(): Promise<string> {
    return await this.closeDateInput.getAttribute('value');
  }

  async setCloseFiscalQuarterInput(closeFiscalQuarter: string): Promise<void> {
    await this.closeFiscalQuarterInput.sendKeys(closeFiscalQuarter);
  }

  async getCloseFiscalQuarterInput(): Promise<string> {
    return await this.closeFiscalQuarterInput.getAttribute('value');
  }

  async setCreatedDateInput(createdDate: string): Promise<void> {
    await this.createdDateInput.sendKeys(createdDate);
  }

  async getCreatedDateInput(): Promise<string> {
    return await this.createdDateInput.getAttribute('value');
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setFopsNamesInput(fopsNames: string): Promise<void> {
    await this.fopsNamesInput.sendKeys(fopsNames);
  }

  async getFopsNamesInput(): Promise<string> {
    return await this.fopsNamesInput.getAttribute('value');
  }

  async setPartnersInput(partners: string): Promise<void> {
    await this.partnersInput.sendKeys(partners);
  }

  async getPartnersInput(): Promise<string> {
    return await this.partnersInput.getAttribute('value');
  }

  async setCompetitorsNamesInput(competitorsNames: string): Promise<void> {
    await this.competitorsNamesInput.sendKeys(competitorsNames);
  }

  async getCompetitorsNamesInput(): Promise<string> {
    return await this.competitorsNamesInput.getAttribute('value');
  }

  async setOpportunityOwnerInput(opportunityOwner: string): Promise<void> {
    await this.opportunityOwnerInput.sendKeys(opportunityOwner);
  }

  async getOpportunityOwnerInput(): Promise<string> {
    return await this.opportunityOwnerInput.getAttribute('value');
  }

  async setAccountOwnerInput(accountOwner: string): Promise<void> {
    await this.accountOwnerInput.sendKeys(accountOwner);
  }

  async getAccountOwnerInput(): Promise<string> {
    return await this.accountOwnerInput.getAttribute('value');
  }

  async setSccountRVPInput(sccountRVP: string): Promise<void> {
    await this.sccountRVPInput.sendKeys(sccountRVP);
  }

  async getSccountRVPInput(): Promise<string> {
    return await this.sccountRVPInput.getAttribute('value');
  }

  async setFiscalYearInput(fiscalYear: string): Promise<void> {
    await this.fiscalYearInput.sendKeys(fiscalYear);
  }

  async getFiscalYearInput(): Promise<string> {
    return await this.fiscalYearInput.getAttribute('value');
  }

  getQualifiedWinLossInput(): ElementFinder {
    return this.qualifiedWinLossInput;
  }

  async setOpportunityShadowOfferingsInput(opportunityShadowOfferings: string): Promise<void> {
    await this.opportunityShadowOfferingsInput.sendKeys(opportunityShadowOfferings);
  }

  async getOpportunityShadowOfferingsInput(): Promise<string> {
    return await this.opportunityShadowOfferingsInput.getAttribute('value');
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class OpportunityDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-opportunity-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-opportunity'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getText();
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
