import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import { OpportunityComponentsPage, OpportunityDeleteDialog, OpportunityUpdatePage } from './opportunity.page-object';

const expect = chai.expect;

describe('Opportunity e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let opportunityComponentsPage: OpportunityComponentsPage;
  let opportunityUpdatePage: OpportunityUpdatePage;
  let opportunityDeleteDialog: OpportunityDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load Opportunities', async () => {
    await navBarPage.goToEntity('opportunity');
    opportunityComponentsPage = new OpportunityComponentsPage();
    await browser.wait(ec.visibilityOf(opportunityComponentsPage.title), 5000);
    expect(await opportunityComponentsPage.getTitle()).to.eq('Opportunities');
    await browser.wait(
      ec.or(ec.visibilityOf(opportunityComponentsPage.entities), ec.visibilityOf(opportunityComponentsPage.noResult)),
      1000
    );
  });

  it('should load create Opportunity page', async () => {
    await opportunityComponentsPage.clickOnCreateButton();
    opportunityUpdatePage = new OpportunityUpdatePage();
    expect(await opportunityUpdatePage.getPageTitle()).to.eq('Create or edit a Opportunity');
    await opportunityUpdatePage.cancel();
  });

  it('should create and save Opportunities', async () => {
    const nbButtonsBeforeCreate = await opportunityComponentsPage.countDeleteButtons();

    await opportunityComponentsPage.clickOnCreateButton();

    await promise.all([
      opportunityUpdatePage.setOpportunityIdInput('opportunityId'),
      opportunityUpdatePage.setAccountNameInput('accountName'),
      opportunityUpdatePage.setOpportunityNameInput('opportunityName'),
      opportunityUpdatePage.setTypeInput('type'),
      opportunityUpdatePage.setOpportunityDomainInput('opportunityDomain'),
      opportunityUpdatePage.setForecastCategoryInput('forecastCategory'),
      opportunityUpdatePage.setOpportunityStageInput('opportunityStage'),
      opportunityUpdatePage.setProbabilityInput('5'),
      opportunityUpdatePage.setOpportunitySizeInput('5'),
      opportunityUpdatePage.setQualifiedDealSizeInput('5'),
      opportunityUpdatePage.setWeightedDealSizeInput('5'),
      opportunityUpdatePage.setCloseDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      opportunityUpdatePage.setCloseFiscalQuarterInput('closeFiscalQuarter'),
      opportunityUpdatePage.setCreatedDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      opportunityUpdatePage.setCreatedByInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      opportunityUpdatePage.setFopsNamesInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      opportunityUpdatePage.setPartnersInput('partners'),
      opportunityUpdatePage.setCompetitorsNamesInput('competitorsNames'),
      opportunityUpdatePage.setOpportunityOwnerInput('opportunityOwner'),
      opportunityUpdatePage.setAccountOwnerInput('accountOwner'),
      opportunityUpdatePage.setSccountRVPInput('sccountRVP'),
      opportunityUpdatePage.setFiscalYearInput('5'),
      opportunityUpdatePage.setOpportunityShadowOfferingsInput('opportunityShadowOfferings')
    ]);

    expect(await opportunityUpdatePage.getOpportunityIdInput()).to.eq(
      'opportunityId',
      'Expected OpportunityId value to be equals to opportunityId'
    );
    expect(await opportunityUpdatePage.getAccountNameInput()).to.eq(
      'accountName',
      'Expected AccountName value to be equals to accountName'
    );
    expect(await opportunityUpdatePage.getOpportunityNameInput()).to.eq(
      'opportunityName',
      'Expected OpportunityName value to be equals to opportunityName'
    );
    expect(await opportunityUpdatePage.getTypeInput()).to.eq('type', 'Expected Type value to be equals to type');
    expect(await opportunityUpdatePage.getOpportunityDomainInput()).to.eq(
      'opportunityDomain',
      'Expected OpportunityDomain value to be equals to opportunityDomain'
    );
    expect(await opportunityUpdatePage.getForecastCategoryInput()).to.eq(
      'forecastCategory',
      'Expected ForecastCategory value to be equals to forecastCategory'
    );
    expect(await opportunityUpdatePage.getOpportunityStageInput()).to.eq(
      'opportunityStage',
      'Expected OpportunityStage value to be equals to opportunityStage'
    );
    expect(await opportunityUpdatePage.getProbabilityInput()).to.eq('5', 'Expected probability value to be equals to 5');
    expect(await opportunityUpdatePage.getOpportunitySizeInput()).to.eq('5', 'Expected opportunitySize value to be equals to 5');
    expect(await opportunityUpdatePage.getQualifiedDealSizeInput()).to.eq('5', 'Expected qualifiedDealSize value to be equals to 5');
    expect(await opportunityUpdatePage.getWeightedDealSizeInput()).to.eq('5', 'Expected weightedDealSize value to be equals to 5');
    expect(await opportunityUpdatePage.getCloseDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected closeDate value to be equals to 2000-12-31'
    );
    expect(await opportunityUpdatePage.getCloseFiscalQuarterInput()).to.eq(
      'closeFiscalQuarter',
      'Expected CloseFiscalQuarter value to be equals to closeFiscalQuarter'
    );
    expect(await opportunityUpdatePage.getCreatedDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected createdDate value to be equals to 2000-12-31'
    );
    expect(await opportunityUpdatePage.getCreatedByInput()).to.contain(
      '2001-01-01T02:30',
      'Expected createdBy value to be equals to 2000-12-31'
    );
    expect(await opportunityUpdatePage.getFopsNamesInput()).to.contain(
      '2001-01-01T02:30',
      'Expected fopsNames value to be equals to 2000-12-31'
    );
    expect(await opportunityUpdatePage.getPartnersInput()).to.eq('partners', 'Expected Partners value to be equals to partners');
    expect(await opportunityUpdatePage.getCompetitorsNamesInput()).to.eq(
      'competitorsNames',
      'Expected CompetitorsNames value to be equals to competitorsNames'
    );
    expect(await opportunityUpdatePage.getOpportunityOwnerInput()).to.eq(
      'opportunityOwner',
      'Expected OpportunityOwner value to be equals to opportunityOwner'
    );
    expect(await opportunityUpdatePage.getAccountOwnerInput()).to.eq(
      'accountOwner',
      'Expected AccountOwner value to be equals to accountOwner'
    );
    expect(await opportunityUpdatePage.getSccountRVPInput()).to.eq('sccountRVP', 'Expected SccountRVP value to be equals to sccountRVP');
    expect(await opportunityUpdatePage.getFiscalYearInput()).to.eq('5', 'Expected fiscalYear value to be equals to 5');
    const selectedQualifiedWinLoss = opportunityUpdatePage.getQualifiedWinLossInput();
    if (await selectedQualifiedWinLoss.isSelected()) {
      await opportunityUpdatePage.getQualifiedWinLossInput().click();
      expect(await opportunityUpdatePage.getQualifiedWinLossInput().isSelected(), 'Expected qualifiedWinLoss not to be selected').to.be
        .false;
    } else {
      await opportunityUpdatePage.getQualifiedWinLossInput().click();
      expect(await opportunityUpdatePage.getQualifiedWinLossInput().isSelected(), 'Expected qualifiedWinLoss to be selected').to.be.true;
    }
    expect(await opportunityUpdatePage.getOpportunityShadowOfferingsInput()).to.eq(
      'opportunityShadowOfferings',
      'Expected OpportunityShadowOfferings value to be equals to opportunityShadowOfferings'
    );

    await opportunityUpdatePage.save();
    expect(await opportunityUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await opportunityComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeCreate + 1, 'Expected one more entry in the table');
  });

  it('should delete last Opportunity', async () => {
    const nbButtonsBeforeDelete = await opportunityComponentsPage.countDeleteButtons();
    await opportunityComponentsPage.clickOnLastDeleteButton();

    opportunityDeleteDialog = new OpportunityDeleteDialog();
    expect(await opportunityDeleteDialog.getDialogTitle()).to.eq('Are you sure you want to delete this Opportunity?');
    await opportunityDeleteDialog.clickOnConfirmButton();

    expect(await opportunityComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
