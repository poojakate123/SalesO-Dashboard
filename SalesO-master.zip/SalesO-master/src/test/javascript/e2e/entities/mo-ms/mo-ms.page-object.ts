import { element, by, ElementFinder } from 'protractor';

export class MoMsComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-mo-ms div table .btn-danger'));
  title = element.all(by.css('jhi-mo-ms div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getText();
  }
}

export class MoMsUpdatePage {
  pageTitle = element(by.id('jhi-mo-ms-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  titleInput = element(by.id('field_title'));
  descriptionInput = element(by.id('field_description'));
  dateInput = element(by.id('field_date'));
  isPositiveInput = element(by.id('field_isPositive'));
  concernInput = element(by.id('field_concern'));
  probabilityInput = element(by.id('field_probability'));

  opportunitySelect = element(by.id('field_opportunity'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getText();
  }

  async setTitleInput(title: string): Promise<void> {
    await this.titleInput.sendKeys(title);
  }

  async getTitleInput(): Promise<string> {
    return await this.titleInput.getAttribute('value');
  }

  async setDescriptionInput(description: string): Promise<void> {
    await this.descriptionInput.sendKeys(description);
  }

  async getDescriptionInput(): Promise<string> {
    return await this.descriptionInput.getAttribute('value');
  }

  async setDateInput(date: string): Promise<void> {
    await this.dateInput.sendKeys(date);
  }

  async getDateInput(): Promise<string> {
    return await this.dateInput.getAttribute('value');
  }

  getIsPositiveInput(): ElementFinder {
    return this.isPositiveInput;
  }

  async setConcernInput(concern: string): Promise<void> {
    await this.concernInput.sendKeys(concern);
  }

  async getConcernInput(): Promise<string> {
    return await this.concernInput.getAttribute('value');
  }

  async setProbabilityInput(probability: string): Promise<void> {
    await this.probabilityInput.sendKeys(probability);
  }

  async getProbabilityInput(): Promise<string> {
    return await this.probabilityInput.getAttribute('value');
  }

  async opportunitySelectLastOption(): Promise<void> {
    await this.opportunitySelect
      .all(by.tagName('option'))
      .last()
      .click();
  }

  async opportunitySelectOption(option: string): Promise<void> {
    await this.opportunitySelect.sendKeys(option);
  }

  getOpportunitySelect(): ElementFinder {
    return this.opportunitySelect;
  }

  async getOpportunitySelectedOption(): Promise<string> {
    return await this.opportunitySelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class MoMsDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-moMs-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-moMs'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getText();
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
