import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import { MoMsComponentsPage, MoMsDeleteDialog, MoMsUpdatePage } from './mo-ms.page-object';

const expect = chai.expect;

describe('MoMs e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let moMsComponentsPage: MoMsComponentsPage;
  let moMsUpdatePage: MoMsUpdatePage;
  let moMsDeleteDialog: MoMsDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load MoMs', async () => {
    await navBarPage.goToEntity('mo-ms');
    moMsComponentsPage = new MoMsComponentsPage();
    await browser.wait(ec.visibilityOf(moMsComponentsPage.title), 5000);
    expect(await moMsComponentsPage.getTitle()).to.eq('Mo Ms');
    await browser.wait(ec.or(ec.visibilityOf(moMsComponentsPage.entities), ec.visibilityOf(moMsComponentsPage.noResult)), 1000);
  });

  it('should load create MoMs page', async () => {
    await moMsComponentsPage.clickOnCreateButton();
    moMsUpdatePage = new MoMsUpdatePage();
    expect(await moMsUpdatePage.getPageTitle()).to.eq('Create or edit a Mo Ms');
    await moMsUpdatePage.cancel();
  });

  it('should create and save MoMs', async () => {
    const nbButtonsBeforeCreate = await moMsComponentsPage.countDeleteButtons();

    await moMsComponentsPage.clickOnCreateButton();

    await promise.all([
      moMsUpdatePage.setTitleInput('title'),
      moMsUpdatePage.setDescriptionInput('description'),
      moMsUpdatePage.setDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      moMsUpdatePage.setConcernInput('concern'),
      moMsUpdatePage.setProbabilityInput('5'),
      moMsUpdatePage.opportunitySelectLastOption()
    ]);

    expect(await moMsUpdatePage.getTitleInput()).to.eq('title', 'Expected Title value to be equals to title');
    expect(await moMsUpdatePage.getDescriptionInput()).to.eq('description', 'Expected Description value to be equals to description');
    expect(await moMsUpdatePage.getDateInput()).to.contain('2001-01-01T02:30', 'Expected date value to be equals to 2000-12-31');
    const selectedIsPositive = moMsUpdatePage.getIsPositiveInput();
    if (await selectedIsPositive.isSelected()) {
      await moMsUpdatePage.getIsPositiveInput().click();
      expect(await moMsUpdatePage.getIsPositiveInput().isSelected(), 'Expected isPositive not to be selected').to.be.false;
    } else {
      await moMsUpdatePage.getIsPositiveInput().click();
      expect(await moMsUpdatePage.getIsPositiveInput().isSelected(), 'Expected isPositive to be selected').to.be.true;
    }
    expect(await moMsUpdatePage.getConcernInput()).to.eq('concern', 'Expected Concern value to be equals to concern');
    expect(await moMsUpdatePage.getProbabilityInput()).to.eq('5', 'Expected probability value to be equals to 5');

    await moMsUpdatePage.save();
    expect(await moMsUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await moMsComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeCreate + 1, 'Expected one more entry in the table');
  });

  it('should delete last MoMs', async () => {
    const nbButtonsBeforeDelete = await moMsComponentsPage.countDeleteButtons();
    await moMsComponentsPage.clickOnLastDeleteButton();

    moMsDeleteDialog = new MoMsDeleteDialog();
    expect(await moMsDeleteDialog.getDialogTitle()).to.eq('Are you sure you want to delete this Mo Ms?');
    await moMsDeleteDialog.clickOnConfirmButton();

    expect(await moMsComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
