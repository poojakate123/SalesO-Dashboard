import { browser, ExpectedConditions as ec, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import { QuestionAnswerComponentsPage, QuestionAnswerDeleteDialog, QuestionAnswerUpdatePage } from './question-answer.page-object';

const expect = chai.expect;

describe('QuestionAnswer e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let questionAnswerComponentsPage: QuestionAnswerComponentsPage;
  let questionAnswerUpdatePage: QuestionAnswerUpdatePage;
  let questionAnswerDeleteDialog: QuestionAnswerDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load QuestionAnswers', async () => {
    await navBarPage.goToEntity('question-answer');
    questionAnswerComponentsPage = new QuestionAnswerComponentsPage();
    await browser.wait(ec.visibilityOf(questionAnswerComponentsPage.title), 5000);
    expect(await questionAnswerComponentsPage.getTitle()).to.eq('Question Answers');
    await browser.wait(
      ec.or(ec.visibilityOf(questionAnswerComponentsPage.entities), ec.visibilityOf(questionAnswerComponentsPage.noResult)),
      1000
    );
  });

  it('should load create QuestionAnswer page', async () => {
    await questionAnswerComponentsPage.clickOnCreateButton();
    questionAnswerUpdatePage = new QuestionAnswerUpdatePage();
    expect(await questionAnswerUpdatePage.getPageTitle()).to.eq('Create or edit a Question Answer');
    await questionAnswerUpdatePage.cancel();
  });

  it('should create and save QuestionAnswers', async () => {
    const nbButtonsBeforeCreate = await questionAnswerComponentsPage.countDeleteButtons();

    await questionAnswerComponentsPage.clickOnCreateButton();

    await promise.all([
      questionAnswerUpdatePage.setQuestionInput('question'),
      questionAnswerUpdatePage.setAnswerInput('answer'),
      questionAnswerUpdatePage.opportunitySelectLastOption()
    ]);

    expect(await questionAnswerUpdatePage.getQuestionInput()).to.eq('question', 'Expected Question value to be equals to question');
    expect(await questionAnswerUpdatePage.getAnswerInput()).to.eq('answer', 'Expected Answer value to be equals to answer');

    await questionAnswerUpdatePage.save();
    expect(await questionAnswerUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await questionAnswerComponentsPage.countDeleteButtons()).to.eq(
      nbButtonsBeforeCreate + 1,
      'Expected one more entry in the table'
    );
  });

  it('should delete last QuestionAnswer', async () => {
    const nbButtonsBeforeDelete = await questionAnswerComponentsPage.countDeleteButtons();
    await questionAnswerComponentsPage.clickOnLastDeleteButton();

    questionAnswerDeleteDialog = new QuestionAnswerDeleteDialog();
    expect(await questionAnswerDeleteDialog.getDialogTitle()).to.eq('Are you sure you want to delete this Question Answer?');
    await questionAnswerDeleteDialog.clickOnConfirmButton();

    expect(await questionAnswerComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
