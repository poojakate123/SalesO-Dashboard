import { element, by, ElementFinder } from 'protractor';

export class QuestionAnswerComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-question-answer div table .btn-danger'));
  title = element.all(by.css('jhi-question-answer div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getText();
  }
}

export class QuestionAnswerUpdatePage {
  pageTitle = element(by.id('jhi-question-answer-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  questionInput = element(by.id('field_question'));
  answerInput = element(by.id('field_answer'));

  opportunitySelect = element(by.id('field_opportunity'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getText();
  }

  async setQuestionInput(question: string): Promise<void> {
    await this.questionInput.sendKeys(question);
  }

  async getQuestionInput(): Promise<string> {
    return await this.questionInput.getAttribute('value');
  }

  async setAnswerInput(answer: string): Promise<void> {
    await this.answerInput.sendKeys(answer);
  }

  async getAnswerInput(): Promise<string> {
    return await this.answerInput.getAttribute('value');
  }

  async opportunitySelectLastOption(): Promise<void> {
    await this.opportunitySelect
      .all(by.tagName('option'))
      .last()
      .click();
  }

  async opportunitySelectOption(option: string): Promise<void> {
    await this.opportunitySelect.sendKeys(option);
  }

  getOpportunitySelect(): ElementFinder {
    return this.opportunitySelect;
  }

  async getOpportunitySelectedOption(): Promise<string> {
    return await this.opportunitySelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class QuestionAnswerDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-questionAnswer-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-questionAnswer'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getText();
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
