import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { of } from 'rxjs';

import { SalesOTestModule } from '../../../test.module';
import { MoMsUpdateComponent } from 'app/entities/mo-ms/mo-ms-update.component';
import { MoMsService } from 'app/entities/mo-ms/mo-ms.service';
import { MoMs } from 'app/shared/model/mo-ms.model';

describe('Component Tests', () => {
  describe('MoMs Management Update Component', () => {
    let comp: MoMsUpdateComponent;
    let fixture: ComponentFixture<MoMsUpdateComponent>;
    let service: MoMsService;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [SalesOTestModule],
        declarations: [MoMsUpdateComponent],
        providers: [FormBuilder]
      })
        .overrideTemplate(MoMsUpdateComponent, '')
        .compileComponents();

      fixture = TestBed.createComponent(MoMsUpdateComponent);
      comp = fixture.componentInstance;
      service = fixture.debugElement.injector.get(MoMsService);
    });

    describe('save', () => {
      it('Should call update service on save for existing entity', fakeAsync(() => {
        // GIVEN
        const entity = new MoMs(123);
        spyOn(service, 'update').and.returnValue(of(new HttpResponse({ body: entity })));
        comp.updateForm(entity);
        // WHEN
        comp.save();
        tick(); // simulate async

        // THEN
        expect(service.update).toHaveBeenCalledWith(entity);
        expect(comp.isSaving).toEqual(false);
      }));

      it('Should call create service on save for new entity', fakeAsync(() => {
        // GIVEN
        const entity = new MoMs();
        spyOn(service, 'create').and.returnValue(of(new HttpResponse({ body: entity })));
        comp.updateForm(entity);
        // WHEN
        comp.save();
        tick(); // simulate async

        // THEN
        expect(service.create).toHaveBeenCalledWith(entity);
        expect(comp.isSaving).toEqual(false);
      }));
    });
  });
});
