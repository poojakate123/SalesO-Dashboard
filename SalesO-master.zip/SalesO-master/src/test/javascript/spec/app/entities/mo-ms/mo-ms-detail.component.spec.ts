import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { SalesOTestModule } from '../../../test.module';
import { MoMsDetailComponent } from 'app/entities/mo-ms/mo-ms-detail.component';
import { MoMs } from 'app/shared/model/mo-ms.model';

describe('Component Tests', () => {
  describe('MoMs Management Detail Component', () => {
    let comp: MoMsDetailComponent;
    let fixture: ComponentFixture<MoMsDetailComponent>;
    const route = ({ data: of({ moMs: new MoMs(123) }) } as any) as ActivatedRoute;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [SalesOTestModule],
        declarations: [MoMsDetailComponent],
        providers: [{ provide: ActivatedRoute, useValue: route }]
      })
        .overrideTemplate(MoMsDetailComponent, '')
        .compileComponents();
      fixture = TestBed.createComponent(MoMsDetailComponent);
      comp = fixture.componentInstance;
    });

    describe('OnInit', () => {
      it('Should load moMs on init', () => {
        // WHEN
        comp.ngOnInit();

        // THEN
        expect(comp.moMs).toEqual(jasmine.objectContaining({ id: 123 }));
      });
    });
  });
});
