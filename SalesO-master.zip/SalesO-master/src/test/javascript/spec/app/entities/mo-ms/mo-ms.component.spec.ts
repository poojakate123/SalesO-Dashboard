import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { HttpHeaders, HttpResponse } from '@angular/common/http';

import { SalesOTestModule } from '../../../test.module';
import { MoMsComponent } from 'app/entities/mo-ms/mo-ms.component';
import { MoMsService } from 'app/entities/mo-ms/mo-ms.service';
import { MoMs } from 'app/shared/model/mo-ms.model';

describe('Component Tests', () => {
  describe('MoMs Management Component', () => {
    let comp: MoMsComponent;
    let fixture: ComponentFixture<MoMsComponent>;
    let service: MoMsService;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [SalesOTestModule],
        declarations: [MoMsComponent]
      })
        .overrideTemplate(MoMsComponent, '')
        .compileComponents();

      fixture = TestBed.createComponent(MoMsComponent);
      comp = fixture.componentInstance;
      service = fixture.debugElement.injector.get(MoMsService);
    });

    it('Should call load all on init', () => {
      // GIVEN
      const headers = new HttpHeaders().append('link', 'link;link');
      spyOn(service, 'query').and.returnValue(
        of(
          new HttpResponse({
            body: [new MoMs(123)],
            headers
          })
        )
      );

      // WHEN
      comp.ngOnInit();

      // THEN
      expect(service.query).toHaveBeenCalled();
      expect(comp.moMs && comp.moMs[0]).toEqual(jasmine.objectContaining({ id: 123 }));
    });
  });
});
