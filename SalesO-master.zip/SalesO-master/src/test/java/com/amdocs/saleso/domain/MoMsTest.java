package com.amdocs.saleso.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.amdocs.saleso.web.rest.TestUtil;

public class MoMsTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(MoMs.class);
        MoMs moMs1 = new MoMs();
        moMs1.setId(1L);
        MoMs moMs2 = new MoMs();
        moMs2.setId(moMs1.getId());
        assertThat(moMs1).isEqualTo(moMs2);
        moMs2.setId(2L);
        assertThat(moMs1).isNotEqualTo(moMs2);
        moMs1.setId(null);
        assertThat(moMs1).isNotEqualTo(moMs2);
    }
}
