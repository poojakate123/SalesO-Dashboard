package com.amdocs.saleso.web.rest;

import com.amdocs.saleso.SalesOApp;
import com.amdocs.saleso.domain.Opportunity;
import com.amdocs.saleso.repository.OpportunityRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link OpportunityResource} REST controller.
 */
@SpringBootTest(classes = SalesOApp.class)

@AutoConfigureMockMvc
@WithMockUser
public class OpportunityResourceIT {

    private static final String DEFAULT_OPPORTUNITY_ID = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_ID = "BBBBBBBBBB";

    private static final String DEFAULT_ACCOUNT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_ACCOUNT_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_OPPORTUNITY_NAME = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_OPPORTUNITY_DOMAIN = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_DOMAIN = "BBBBBBBBBB";

    private static final String DEFAULT_FORECAST_CATEGORY = "AAAAAAAAAA";
    private static final String UPDATED_FORECAST_CATEGORY = "BBBBBBBBBB";

    private static final String DEFAULT_OPPORTUNITY_STAGE = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_STAGE = "BBBBBBBBBB";

    private static final Double DEFAULT_PROBABILITY = 1D;
    private static final Double UPDATED_PROBABILITY = 2D;

    private static final Double DEFAULT_OPPORTUNITY_SIZE = 1D;
    private static final Double UPDATED_OPPORTUNITY_SIZE = 2D;

    private static final Double DEFAULT_QUALIFIED_DEAL_SIZE = 1D;
    private static final Double UPDATED_QUALIFIED_DEAL_SIZE = 2D;

    private static final Double DEFAULT_WEIGHTED_DEAL_SIZE = 1D;
    private static final Double UPDATED_WEIGHTED_DEAL_SIZE = 2D;

    private static final Instant DEFAULT_CLOSE_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_CLOSE_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_CLOSE_FISCAL_QUARTER = "AAAAAAAAAA";
    private static final String UPDATED_CLOSE_FISCAL_QUARTER = "BBBBBBBBBB";

    private static final Instant DEFAULT_CREATED_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_CREATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final Instant DEFAULT_CREATED_BY = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_CREATED_BY = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final Instant DEFAULT_FOPS_NAMES = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_FOPS_NAMES = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_PARTNERS = "AAAAAAAAAA";
    private static final String UPDATED_PARTNERS = "BBBBBBBBBB";

    private static final String DEFAULT_COMPETITORS_NAMES = "AAAAAAAAAA";
    private static final String UPDATED_COMPETITORS_NAMES = "BBBBBBBBBB";

    private static final String DEFAULT_OPPORTUNITY_OWNER = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_OWNER = "BBBBBBBBBB";

    private static final String DEFAULT_ACCOUNT_OWNER = "AAAAAAAAAA";
    private static final String UPDATED_ACCOUNT_OWNER = "BBBBBBBBBB";

    private static final String DEFAULT_SCCOUNT_RVP = "AAAAAAAAAA";
    private static final String UPDATED_SCCOUNT_RVP = "BBBBBBBBBB";

    private static final Integer DEFAULT_FISCAL_YEAR = 1;
    private static final Integer UPDATED_FISCAL_YEAR = 2;

    private static final Boolean DEFAULT_QUALIFIED_WIN_LOSS = false;
    private static final Boolean UPDATED_QUALIFIED_WIN_LOSS = true;

    private static final String DEFAULT_OPPORTUNITY_SHADOW_OFFERINGS = "AAAAAAAAAA";
    private static final String UPDATED_OPPORTUNITY_SHADOW_OFFERINGS = "BBBBBBBBBB";

    @Autowired
    private OpportunityRepository opportunityRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restOpportunityMockMvc;

    private Opportunity opportunity;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Opportunity createEntity(EntityManager em) {
        Opportunity opportunity = new Opportunity()
            .opportunityId(DEFAULT_OPPORTUNITY_ID)
            .accountName(DEFAULT_ACCOUNT_NAME)
            .opportunityName(DEFAULT_OPPORTUNITY_NAME)
            .type(DEFAULT_TYPE)
            .opportunityDomain(DEFAULT_OPPORTUNITY_DOMAIN)
            .forecastCategory(DEFAULT_FORECAST_CATEGORY)
            .opportunityStage(DEFAULT_OPPORTUNITY_STAGE)
            .probability(DEFAULT_PROBABILITY)
            .opportunitySize(DEFAULT_OPPORTUNITY_SIZE)
            .qualifiedDealSize(DEFAULT_QUALIFIED_DEAL_SIZE)
            .weightedDealSize(DEFAULT_WEIGHTED_DEAL_SIZE)
            .closeDate(DEFAULT_CLOSE_DATE)
            .closeFiscalQuarter(DEFAULT_CLOSE_FISCAL_QUARTER)
            .createdDate(DEFAULT_CREATED_DATE)
            .createdBy(DEFAULT_CREATED_BY)
            .fopsNames(DEFAULT_FOPS_NAMES)
            .partners(DEFAULT_PARTNERS)
            .competitorsNames(DEFAULT_COMPETITORS_NAMES)
            .opportunityOwner(DEFAULT_OPPORTUNITY_OWNER)
            .accountOwner(DEFAULT_ACCOUNT_OWNER)
            .sccountRVP(DEFAULT_SCCOUNT_RVP)
            .fiscalYear(DEFAULT_FISCAL_YEAR)
            .qualifiedWinLoss(DEFAULT_QUALIFIED_WIN_LOSS)
            .opportunityShadowOfferings(DEFAULT_OPPORTUNITY_SHADOW_OFFERINGS);
        return opportunity;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Opportunity createUpdatedEntity(EntityManager em) {
        Opportunity opportunity = new Opportunity()
            .opportunityId(UPDATED_OPPORTUNITY_ID)
            .accountName(UPDATED_ACCOUNT_NAME)
            .opportunityName(UPDATED_OPPORTUNITY_NAME)
            .type(UPDATED_TYPE)
            .opportunityDomain(UPDATED_OPPORTUNITY_DOMAIN)
            .forecastCategory(UPDATED_FORECAST_CATEGORY)
            .opportunityStage(UPDATED_OPPORTUNITY_STAGE)
            .probability(UPDATED_PROBABILITY)
            .opportunitySize(UPDATED_OPPORTUNITY_SIZE)
            .qualifiedDealSize(UPDATED_QUALIFIED_DEAL_SIZE)
            .weightedDealSize(UPDATED_WEIGHTED_DEAL_SIZE)
            .closeDate(UPDATED_CLOSE_DATE)
            .closeFiscalQuarter(UPDATED_CLOSE_FISCAL_QUARTER)
            .createdDate(UPDATED_CREATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .fopsNames(UPDATED_FOPS_NAMES)
            .partners(UPDATED_PARTNERS)
            .competitorsNames(UPDATED_COMPETITORS_NAMES)
            .opportunityOwner(UPDATED_OPPORTUNITY_OWNER)
            .accountOwner(UPDATED_ACCOUNT_OWNER)
            .sccountRVP(UPDATED_SCCOUNT_RVP)
            .fiscalYear(UPDATED_FISCAL_YEAR)
            .qualifiedWinLoss(UPDATED_QUALIFIED_WIN_LOSS)
            .opportunityShadowOfferings(UPDATED_OPPORTUNITY_SHADOW_OFFERINGS);
        return opportunity;
    }

    @BeforeEach
    public void initTest() {
        opportunity = createEntity(em);
    }

    @Test
    @Transactional
    public void createOpportunity() throws Exception {
        int databaseSizeBeforeCreate = opportunityRepository.findAll().size();

        // Create the Opportunity
        restOpportunityMockMvc.perform(post("/api/opportunities").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(opportunity)))
            .andExpect(status().isCreated());

        // Validate the Opportunity in the database
        List<Opportunity> opportunityList = opportunityRepository.findAll();
        assertThat(opportunityList).hasSize(databaseSizeBeforeCreate + 1);
        Opportunity testOpportunity = opportunityList.get(opportunityList.size() - 1);
        assertThat(testOpportunity.getOpportunityId()).isEqualTo(DEFAULT_OPPORTUNITY_ID);
        assertThat(testOpportunity.getAccountName()).isEqualTo(DEFAULT_ACCOUNT_NAME);
        assertThat(testOpportunity.getOpportunityName()).isEqualTo(DEFAULT_OPPORTUNITY_NAME);
        assertThat(testOpportunity.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testOpportunity.getOpportunityDomain()).isEqualTo(DEFAULT_OPPORTUNITY_DOMAIN);
        assertThat(testOpportunity.getForecastCategory()).isEqualTo(DEFAULT_FORECAST_CATEGORY);
        assertThat(testOpportunity.getOpportunityStage()).isEqualTo(DEFAULT_OPPORTUNITY_STAGE);
        assertThat(testOpportunity.getProbability()).isEqualTo(DEFAULT_PROBABILITY);
        assertThat(testOpportunity.getOpportunitySize()).isEqualTo(DEFAULT_OPPORTUNITY_SIZE);
        assertThat(testOpportunity.getQualifiedDealSize()).isEqualTo(DEFAULT_QUALIFIED_DEAL_SIZE);
        assertThat(testOpportunity.getWeightedDealSize()).isEqualTo(DEFAULT_WEIGHTED_DEAL_SIZE);
        assertThat(testOpportunity.getCloseDate()).isEqualTo(DEFAULT_CLOSE_DATE);
        assertThat(testOpportunity.getCloseFiscalQuarter()).isEqualTo(DEFAULT_CLOSE_FISCAL_QUARTER);
        assertThat(testOpportunity.getCreatedDate()).isEqualTo(DEFAULT_CREATED_DATE);
        assertThat(testOpportunity.getCreatedBy()).isEqualTo(DEFAULT_CREATED_BY);
        assertThat(testOpportunity.getFopsNames()).isEqualTo(DEFAULT_FOPS_NAMES);
        assertThat(testOpportunity.getPartners()).isEqualTo(DEFAULT_PARTNERS);
        assertThat(testOpportunity.getCompetitorsNames()).isEqualTo(DEFAULT_COMPETITORS_NAMES);
        assertThat(testOpportunity.getOpportunityOwner()).isEqualTo(DEFAULT_OPPORTUNITY_OWNER);
        assertThat(testOpportunity.getAccountOwner()).isEqualTo(DEFAULT_ACCOUNT_OWNER);
        assertThat(testOpportunity.getSccountRVP()).isEqualTo(DEFAULT_SCCOUNT_RVP);
        assertThat(testOpportunity.getFiscalYear()).isEqualTo(DEFAULT_FISCAL_YEAR);
        assertThat(testOpportunity.isQualifiedWinLoss()).isEqualTo(DEFAULT_QUALIFIED_WIN_LOSS);
        assertThat(testOpportunity.getOpportunityShadowOfferings()).isEqualTo(DEFAULT_OPPORTUNITY_SHADOW_OFFERINGS);
    }

    @Test
    @Transactional
    public void createOpportunityWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = opportunityRepository.findAll().size();

        // Create the Opportunity with an existing ID
        opportunity.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restOpportunityMockMvc.perform(post("/api/opportunities").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(opportunity)))
            .andExpect(status().isBadRequest());

        // Validate the Opportunity in the database
        List<Opportunity> opportunityList = opportunityRepository.findAll();
        assertThat(opportunityList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllOpportunities() throws Exception {
        // Initialize the database
        opportunityRepository.saveAndFlush(opportunity);

        // Get all the opportunityList
        restOpportunityMockMvc.perform(get("/api/opportunities?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(opportunity.getId().intValue())))
            .andExpect(jsonPath("$.[*].opportunityId").value(hasItem(DEFAULT_OPPORTUNITY_ID)))
            .andExpect(jsonPath("$.[*].accountName").value(hasItem(DEFAULT_ACCOUNT_NAME)))
            .andExpect(jsonPath("$.[*].opportunityName").value(hasItem(DEFAULT_OPPORTUNITY_NAME)))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE)))
            .andExpect(jsonPath("$.[*].opportunityDomain").value(hasItem(DEFAULT_OPPORTUNITY_DOMAIN)))
            .andExpect(jsonPath("$.[*].forecastCategory").value(hasItem(DEFAULT_FORECAST_CATEGORY)))
            .andExpect(jsonPath("$.[*].opportunityStage").value(hasItem(DEFAULT_OPPORTUNITY_STAGE)))
            .andExpect(jsonPath("$.[*].probability").value(hasItem(DEFAULT_PROBABILITY.doubleValue())))
            .andExpect(jsonPath("$.[*].opportunitySize").value(hasItem(DEFAULT_OPPORTUNITY_SIZE.doubleValue())))
            .andExpect(jsonPath("$.[*].qualifiedDealSize").value(hasItem(DEFAULT_QUALIFIED_DEAL_SIZE.doubleValue())))
            .andExpect(jsonPath("$.[*].weightedDealSize").value(hasItem(DEFAULT_WEIGHTED_DEAL_SIZE.doubleValue())))
            .andExpect(jsonPath("$.[*].closeDate").value(hasItem(DEFAULT_CLOSE_DATE.toString())))
            .andExpect(jsonPath("$.[*].closeFiscalQuarter").value(hasItem(DEFAULT_CLOSE_FISCAL_QUARTER)))
            .andExpect(jsonPath("$.[*].createdDate").value(hasItem(DEFAULT_CREATED_DATE.toString())))
            .andExpect(jsonPath("$.[*].createdBy").value(hasItem(DEFAULT_CREATED_BY.toString())))
            .andExpect(jsonPath("$.[*].fopsNames").value(hasItem(DEFAULT_FOPS_NAMES.toString())))
            .andExpect(jsonPath("$.[*].partners").value(hasItem(DEFAULT_PARTNERS)))
            .andExpect(jsonPath("$.[*].competitorsNames").value(hasItem(DEFAULT_COMPETITORS_NAMES)))
            .andExpect(jsonPath("$.[*].opportunityOwner").value(hasItem(DEFAULT_OPPORTUNITY_OWNER)))
            .andExpect(jsonPath("$.[*].accountOwner").value(hasItem(DEFAULT_ACCOUNT_OWNER)))
            .andExpect(jsonPath("$.[*].sccountRVP").value(hasItem(DEFAULT_SCCOUNT_RVP)))
            .andExpect(jsonPath("$.[*].fiscalYear").value(hasItem(DEFAULT_FISCAL_YEAR)))
            .andExpect(jsonPath("$.[*].qualifiedWinLoss").value(hasItem(DEFAULT_QUALIFIED_WIN_LOSS.booleanValue())))
            .andExpect(jsonPath("$.[*].opportunityShadowOfferings").value(hasItem(DEFAULT_OPPORTUNITY_SHADOW_OFFERINGS)));
    }
    
    @Test
    @Transactional
    public void getOpportunity() throws Exception {
        // Initialize the database
        opportunityRepository.saveAndFlush(opportunity);

        // Get the opportunity
        restOpportunityMockMvc.perform(get("/api/opportunities/{id}", opportunity.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(opportunity.getId().intValue()))
            .andExpect(jsonPath("$.opportunityId").value(DEFAULT_OPPORTUNITY_ID))
            .andExpect(jsonPath("$.accountName").value(DEFAULT_ACCOUNT_NAME))
            .andExpect(jsonPath("$.opportunityName").value(DEFAULT_OPPORTUNITY_NAME))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE))
            .andExpect(jsonPath("$.opportunityDomain").value(DEFAULT_OPPORTUNITY_DOMAIN))
            .andExpect(jsonPath("$.forecastCategory").value(DEFAULT_FORECAST_CATEGORY))
            .andExpect(jsonPath("$.opportunityStage").value(DEFAULT_OPPORTUNITY_STAGE))
            .andExpect(jsonPath("$.probability").value(DEFAULT_PROBABILITY.doubleValue()))
            .andExpect(jsonPath("$.opportunitySize").value(DEFAULT_OPPORTUNITY_SIZE.doubleValue()))
            .andExpect(jsonPath("$.qualifiedDealSize").value(DEFAULT_QUALIFIED_DEAL_SIZE.doubleValue()))
            .andExpect(jsonPath("$.weightedDealSize").value(DEFAULT_WEIGHTED_DEAL_SIZE.doubleValue()))
            .andExpect(jsonPath("$.closeDate").value(DEFAULT_CLOSE_DATE.toString()))
            .andExpect(jsonPath("$.closeFiscalQuarter").value(DEFAULT_CLOSE_FISCAL_QUARTER))
            .andExpect(jsonPath("$.createdDate").value(DEFAULT_CREATED_DATE.toString()))
            .andExpect(jsonPath("$.createdBy").value(DEFAULT_CREATED_BY.toString()))
            .andExpect(jsonPath("$.fopsNames").value(DEFAULT_FOPS_NAMES.toString()))
            .andExpect(jsonPath("$.partners").value(DEFAULT_PARTNERS))
            .andExpect(jsonPath("$.competitorsNames").value(DEFAULT_COMPETITORS_NAMES))
            .andExpect(jsonPath("$.opportunityOwner").value(DEFAULT_OPPORTUNITY_OWNER))
            .andExpect(jsonPath("$.accountOwner").value(DEFAULT_ACCOUNT_OWNER))
            .andExpect(jsonPath("$.sccountRVP").value(DEFAULT_SCCOUNT_RVP))
            .andExpect(jsonPath("$.fiscalYear").value(DEFAULT_FISCAL_YEAR))
            .andExpect(jsonPath("$.qualifiedWinLoss").value(DEFAULT_QUALIFIED_WIN_LOSS.booleanValue()))
            .andExpect(jsonPath("$.opportunityShadowOfferings").value(DEFAULT_OPPORTUNITY_SHADOW_OFFERINGS));
    }

    @Test
    @Transactional
    public void getNonExistingOpportunity() throws Exception {
        // Get the opportunity
        restOpportunityMockMvc.perform(get("/api/opportunities/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateOpportunity() throws Exception {
        // Initialize the database
        opportunityRepository.saveAndFlush(opportunity);

        int databaseSizeBeforeUpdate = opportunityRepository.findAll().size();

        // Update the opportunity
        Opportunity updatedOpportunity = opportunityRepository.findById(opportunity.getId()).get();
        // Disconnect from session so that the updates on updatedOpportunity are not directly saved in db
        em.detach(updatedOpportunity);
        updatedOpportunity
            .opportunityId(UPDATED_OPPORTUNITY_ID)
            .accountName(UPDATED_ACCOUNT_NAME)
            .opportunityName(UPDATED_OPPORTUNITY_NAME)
            .type(UPDATED_TYPE)
            .opportunityDomain(UPDATED_OPPORTUNITY_DOMAIN)
            .forecastCategory(UPDATED_FORECAST_CATEGORY)
            .opportunityStage(UPDATED_OPPORTUNITY_STAGE)
            .probability(UPDATED_PROBABILITY)
            .opportunitySize(UPDATED_OPPORTUNITY_SIZE)
            .qualifiedDealSize(UPDATED_QUALIFIED_DEAL_SIZE)
            .weightedDealSize(UPDATED_WEIGHTED_DEAL_SIZE)
            .closeDate(UPDATED_CLOSE_DATE)
            .closeFiscalQuarter(UPDATED_CLOSE_FISCAL_QUARTER)
            .createdDate(UPDATED_CREATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .fopsNames(UPDATED_FOPS_NAMES)
            .partners(UPDATED_PARTNERS)
            .competitorsNames(UPDATED_COMPETITORS_NAMES)
            .opportunityOwner(UPDATED_OPPORTUNITY_OWNER)
            .accountOwner(UPDATED_ACCOUNT_OWNER)
            .sccountRVP(UPDATED_SCCOUNT_RVP)
            .fiscalYear(UPDATED_FISCAL_YEAR)
            .qualifiedWinLoss(UPDATED_QUALIFIED_WIN_LOSS)
            .opportunityShadowOfferings(UPDATED_OPPORTUNITY_SHADOW_OFFERINGS);

        restOpportunityMockMvc.perform(put("/api/opportunities").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedOpportunity)))
            .andExpect(status().isOk());

        // Validate the Opportunity in the database
        List<Opportunity> opportunityList = opportunityRepository.findAll();
        assertThat(opportunityList).hasSize(databaseSizeBeforeUpdate);
        Opportunity testOpportunity = opportunityList.get(opportunityList.size() - 1);
        assertThat(testOpportunity.getOpportunityId()).isEqualTo(UPDATED_OPPORTUNITY_ID);
        assertThat(testOpportunity.getAccountName()).isEqualTo(UPDATED_ACCOUNT_NAME);
        assertThat(testOpportunity.getOpportunityName()).isEqualTo(UPDATED_OPPORTUNITY_NAME);
        assertThat(testOpportunity.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testOpportunity.getOpportunityDomain()).isEqualTo(UPDATED_OPPORTUNITY_DOMAIN);
        assertThat(testOpportunity.getForecastCategory()).isEqualTo(UPDATED_FORECAST_CATEGORY);
        assertThat(testOpportunity.getOpportunityStage()).isEqualTo(UPDATED_OPPORTUNITY_STAGE);
        assertThat(testOpportunity.getProbability()).isEqualTo(UPDATED_PROBABILITY);
        assertThat(testOpportunity.getOpportunitySize()).isEqualTo(UPDATED_OPPORTUNITY_SIZE);
        assertThat(testOpportunity.getQualifiedDealSize()).isEqualTo(UPDATED_QUALIFIED_DEAL_SIZE);
        assertThat(testOpportunity.getWeightedDealSize()).isEqualTo(UPDATED_WEIGHTED_DEAL_SIZE);
        assertThat(testOpportunity.getCloseDate()).isEqualTo(UPDATED_CLOSE_DATE);
        assertThat(testOpportunity.getCloseFiscalQuarter()).isEqualTo(UPDATED_CLOSE_FISCAL_QUARTER);
        assertThat(testOpportunity.getCreatedDate()).isEqualTo(UPDATED_CREATED_DATE);
        assertThat(testOpportunity.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testOpportunity.getFopsNames()).isEqualTo(UPDATED_FOPS_NAMES);
        assertThat(testOpportunity.getPartners()).isEqualTo(UPDATED_PARTNERS);
        assertThat(testOpportunity.getCompetitorsNames()).isEqualTo(UPDATED_COMPETITORS_NAMES);
        assertThat(testOpportunity.getOpportunityOwner()).isEqualTo(UPDATED_OPPORTUNITY_OWNER);
        assertThat(testOpportunity.getAccountOwner()).isEqualTo(UPDATED_ACCOUNT_OWNER);
        assertThat(testOpportunity.getSccountRVP()).isEqualTo(UPDATED_SCCOUNT_RVP);
        assertThat(testOpportunity.getFiscalYear()).isEqualTo(UPDATED_FISCAL_YEAR);
        assertThat(testOpportunity.isQualifiedWinLoss()).isEqualTo(UPDATED_QUALIFIED_WIN_LOSS);
        assertThat(testOpportunity.getOpportunityShadowOfferings()).isEqualTo(UPDATED_OPPORTUNITY_SHADOW_OFFERINGS);
    }

    @Test
    @Transactional
    public void updateNonExistingOpportunity() throws Exception {
        int databaseSizeBeforeUpdate = opportunityRepository.findAll().size();

        // Create the Opportunity

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restOpportunityMockMvc.perform(put("/api/opportunities").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(opportunity)))
            .andExpect(status().isBadRequest());

        // Validate the Opportunity in the database
        List<Opportunity> opportunityList = opportunityRepository.findAll();
        assertThat(opportunityList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteOpportunity() throws Exception {
        // Initialize the database
        opportunityRepository.saveAndFlush(opportunity);

        int databaseSizeBeforeDelete = opportunityRepository.findAll().size();

        // Delete the opportunity
        restOpportunityMockMvc.perform(delete("/api/opportunities/{id}", opportunity.getId()).with(csrf())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Opportunity> opportunityList = opportunityRepository.findAll();
        assertThat(opportunityList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
