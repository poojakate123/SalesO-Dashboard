package com.amdocs.saleso.web.rest;

import com.amdocs.saleso.SalesOApp;
import com.amdocs.saleso.domain.MoMs;
import com.amdocs.saleso.repository.MoMsRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link MoMsResource} REST controller.
 */
@SpringBootTest(classes = SalesOApp.class)

@AutoConfigureMockMvc
@WithMockUser
public class MoMsResourceIT {

    private static final String DEFAULT_TITLE = "AAAAAAAAAA";
    private static final String UPDATED_TITLE = "BBBBBBBBBB";

    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBB";

    private static final Instant DEFAULT_DATE = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final Boolean DEFAULT_IS_POSITIVE = false;
    private static final Boolean UPDATED_IS_POSITIVE = true;

    private static final String DEFAULT_CONCERN = "AAAAAAAAAA";
    private static final String UPDATED_CONCERN = "BBBBBBBBBB";

    private static final Integer DEFAULT_PROBABILITY = 1;
    private static final Integer UPDATED_PROBABILITY = 2;

    @Autowired
    private MoMsRepository moMsRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restMoMsMockMvc;

    private MoMs moMs;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static MoMs createEntity(EntityManager em) {
        MoMs moMs = new MoMs()
            .title(DEFAULT_TITLE)
            .description(DEFAULT_DESCRIPTION)
            .date(DEFAULT_DATE)
            .isPositive(DEFAULT_IS_POSITIVE)
            .concern(DEFAULT_CONCERN)
            .probability(DEFAULT_PROBABILITY);
        return moMs;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static MoMs createUpdatedEntity(EntityManager em) {
        MoMs moMs = new MoMs()
            .title(UPDATED_TITLE)
            .description(UPDATED_DESCRIPTION)
            .date(UPDATED_DATE)
            .isPositive(UPDATED_IS_POSITIVE)
            .concern(UPDATED_CONCERN)
            .probability(UPDATED_PROBABILITY);
        return moMs;
    }

    @BeforeEach
    public void initTest() {
        moMs = createEntity(em);
    }

    @Test
    @Transactional
    public void createMoMs() throws Exception {
        int databaseSizeBeforeCreate = moMsRepository.findAll().size();

        // Create the MoMs
        restMoMsMockMvc.perform(post("/api/mo-ms").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(moMs)))
            .andExpect(status().isCreated());

        // Validate the MoMs in the database
        List<MoMs> moMsList = moMsRepository.findAll();
        assertThat(moMsList).hasSize(databaseSizeBeforeCreate + 1);
        MoMs testMoMs = moMsList.get(moMsList.size() - 1);
        assertThat(testMoMs.getTitle()).isEqualTo(DEFAULT_TITLE);
        assertThat(testMoMs.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testMoMs.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testMoMs.isIsPositive()).isEqualTo(DEFAULT_IS_POSITIVE);
        assertThat(testMoMs.getConcern()).isEqualTo(DEFAULT_CONCERN);
        assertThat(testMoMs.getProbability()).isEqualTo(DEFAULT_PROBABILITY);
    }

    @Test
    @Transactional
    public void createMoMsWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = moMsRepository.findAll().size();

        // Create the MoMs with an existing ID
        moMs.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restMoMsMockMvc.perform(post("/api/mo-ms").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(moMs)))
            .andExpect(status().isBadRequest());

        // Validate the MoMs in the database
        List<MoMs> moMsList = moMsRepository.findAll();
        assertThat(moMsList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllMoMs() throws Exception {
        // Initialize the database
        moMsRepository.saveAndFlush(moMs);

        // Get all the moMsList
        restMoMsMockMvc.perform(get("/api/mo-ms?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(moMs.getId().intValue())))
            .andExpect(jsonPath("$.[*].title").value(hasItem(DEFAULT_TITLE)))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION)))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].isPositive").value(hasItem(DEFAULT_IS_POSITIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].concern").value(hasItem(DEFAULT_CONCERN)))
            .andExpect(jsonPath("$.[*].probability").value(hasItem(DEFAULT_PROBABILITY)));
    }
    
    @Test
    @Transactional
    public void getMoMs() throws Exception {
        // Initialize the database
        moMsRepository.saveAndFlush(moMs);

        // Get the moMs
        restMoMsMockMvc.perform(get("/api/mo-ms/{id}", moMs.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(moMs.getId().intValue()))
            .andExpect(jsonPath("$.title").value(DEFAULT_TITLE))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.isPositive").value(DEFAULT_IS_POSITIVE.booleanValue()))
            .andExpect(jsonPath("$.concern").value(DEFAULT_CONCERN))
            .andExpect(jsonPath("$.probability").value(DEFAULT_PROBABILITY));
    }

    @Test
    @Transactional
    public void getNonExistingMoMs() throws Exception {
        // Get the moMs
        restMoMsMockMvc.perform(get("/api/mo-ms/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateMoMs() throws Exception {
        // Initialize the database
        moMsRepository.saveAndFlush(moMs);

        int databaseSizeBeforeUpdate = moMsRepository.findAll().size();

        // Update the moMs
        MoMs updatedMoMs = moMsRepository.findById(moMs.getId()).get();
        // Disconnect from session so that the updates on updatedMoMs are not directly saved in db
        em.detach(updatedMoMs);
        updatedMoMs
            .title(UPDATED_TITLE)
            .description(UPDATED_DESCRIPTION)
            .date(UPDATED_DATE)
            .isPositive(UPDATED_IS_POSITIVE)
            .concern(UPDATED_CONCERN)
            .probability(UPDATED_PROBABILITY);

        restMoMsMockMvc.perform(put("/api/mo-ms").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedMoMs)))
            .andExpect(status().isOk());

        // Validate the MoMs in the database
        List<MoMs> moMsList = moMsRepository.findAll();
        assertThat(moMsList).hasSize(databaseSizeBeforeUpdate);
        MoMs testMoMs = moMsList.get(moMsList.size() - 1);
        assertThat(testMoMs.getTitle()).isEqualTo(UPDATED_TITLE);
        assertThat(testMoMs.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testMoMs.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testMoMs.isIsPositive()).isEqualTo(UPDATED_IS_POSITIVE);
        assertThat(testMoMs.getConcern()).isEqualTo(UPDATED_CONCERN);
        assertThat(testMoMs.getProbability()).isEqualTo(UPDATED_PROBABILITY);
    }

    @Test
    @Transactional
    public void updateNonExistingMoMs() throws Exception {
        int databaseSizeBeforeUpdate = moMsRepository.findAll().size();

        // Create the MoMs

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restMoMsMockMvc.perform(put("/api/mo-ms").with(csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(moMs)))
            .andExpect(status().isBadRequest());

        // Validate the MoMs in the database
        List<MoMs> moMsList = moMsRepository.findAll();
        assertThat(moMsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteMoMs() throws Exception {
        // Initialize the database
        moMsRepository.saveAndFlush(moMs);

        int databaseSizeBeforeDelete = moMsRepository.findAll().size();

        // Delete the moMs
        restMoMsMockMvc.perform(delete("/api/mo-ms/{id}", moMs.getId()).with(csrf())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<MoMs> moMsList = moMsRepository.findAll();
        assertThat(moMsList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
