/**
 * Data Transfer Objects.
 */
package com.amdocs.saleso.service.dto;
