package com.amdocs.saleso.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;
import java.time.Instant;

/**
 * A MoMs.
 */
@Entity
@Table(name = "mo_ms")
public class MoMs implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "date")
    private Instant date;

    @Column(name = "is_positive")
    private Boolean isPositive;

    @Column(name = "concern")
    private String concern;

    @Column(name = "probability")
    private Integer probability;

    @ManyToOne
    @JsonIgnoreProperties("moMs")
    private Opportunity opportunity;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public MoMs title(String title) {
        this.title = title;
        return this;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public MoMs description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Instant getDate() {
        return date;
    }

    public MoMs date(Instant date) {
        this.date = date;
        return this;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public Boolean isIsPositive() {
        return isPositive;
    }

    public MoMs isPositive(Boolean isPositive) {
        this.isPositive = isPositive;
        return this;
    }

    public void setIsPositive(Boolean isPositive) {
        this.isPositive = isPositive;
    }

    public String getConcern() {
        return concern;
    }

    public MoMs concern(String concern) {
        this.concern = concern;
        return this;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }

    public Integer getProbability() {
        return probability;
    }

    public MoMs probability(Integer probability) {
        this.probability = probability;
        return this;
    }

    public void setProbability(Integer probability) {
        this.probability = probability;
    }

    public Opportunity getOpportunity() {
        return opportunity;
    }

    public MoMs opportunity(Opportunity opportunity) {
        this.opportunity = opportunity;
        return this;
    }

    public void setOpportunity(Opportunity opportunity) {
        this.opportunity = opportunity;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MoMs)) {
            return false;
        }
        return id != null && id.equals(((MoMs) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "MoMs{" +
            "id=" + getId() +
            ", title='" + getTitle() + "'" +
            ", description='" + getDescription() + "'" +
            ", date='" + getDate() + "'" +
            ", isPositive='" + isIsPositive() + "'" +
            ", concern='" + getConcern() + "'" +
            ", probability=" + getProbability() +
            "}";
    }
}
