package com.amdocs.saleso.web.rest;

import com.amdocs.saleso.domain.MoMs;
import com.amdocs.saleso.domain.Opportunity;
import com.amdocs.saleso.domain.QuestionAnswer;
import com.amdocs.saleso.repository.MoMsRepository;
import com.amdocs.saleso.repository.OpportunityRepository;
import com.amdocs.saleso.repository.QuestionAnswerRepository;
import com.amdocs.saleso.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.HashSet;
import java.util.Set;

/**
 * REST controller for managing {@link com.amdocs.saleso.domain.Opportunity}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class OpportunityResource {

    private final Logger log = LoggerFactory.getLogger(OpportunityResource.class);

    private static final String ENTITY_NAME = "opportunity";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final OpportunityRepository opportunityRepository;
    private final QuestionAnswerRepository questionAnswerRepository;
    private final MoMsRepository moMsRepository;

    public OpportunityResource(OpportunityRepository opportunityRepository, QuestionAnswerRepository questionAnswerRepository, MoMsRepository moMsRepository) {
        this.opportunityRepository = opportunityRepository;
        this.questionAnswerRepository = questionAnswerRepository;
        this.moMsRepository = moMsRepository;
    }

    /**
     * {@code POST  /opportunities} : Create a new opportunity.
     *
     * @param opportunity the opportunity to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new opportunity, or with status {@code 400 (Bad Request)} if the opportunity has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/opportunities")
    public ResponseEntity<Opportunity> createOpportunity(@RequestBody Opportunity opportunity) throws URISyntaxException {
        log.debug("REST request to save Opportunity : {}", opportunity);
        if (opportunity.getId() != null) {
            throw new BadRequestAlertException("A new opportunity cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Opportunity result = opportunityRepository.save(opportunity);
        return ResponseEntity.created(new URI("/api/opportunities/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

        /**
     * {@code POST  /opportunities} : Create a new opportunity.
     *
     * @param opportunity the opportunity to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new opportunity, or with status {@code 400 (Bad Request)} if the opportunity has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/opportunities/save-many")
    public ResponseEntity<List<Opportunity>> createManyOpportunities(@RequestBody List<Opportunity> opportunities) throws URISyntaxException {
        // log.debug("REST request to save Multiple Opportunities : {}", opportunities);
        // if (opportunity.getId() != null) {
        //     throw new BadRequestAlertException("A new opportunity cannot already have an ID", ENTITY_NAME, "idexists");
        // }
        List<Opportunity> results = opportunityRepository.saveAll(opportunities);
        return ResponseEntity.created(new URI("/api/opportunities/save-many"))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, ""))
            .body(results);
    }



    /**
     * {@code PUT  /opportunities} : Updates an existing opportunity.
     *
     * @param opportunity the opportunity to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated opportunity,
     * or with status {@code 400 (Bad Request)} if the opportunity is not valid,
     * or with status {@code 500 (Internal Server Error)} if the opportunity couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/opportunities")
    public ResponseEntity<Opportunity> updateOpportunity(@RequestBody Opportunity opportunity) throws URISyntaxException {
        log.debug("REST request to update Opportunity : {}", opportunity);
        if (opportunity.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Opportunity result = opportunityRepository.save(opportunity);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, opportunity.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /opportunities} : get all the opportunities.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of opportunities in body.
     */
    @GetMapping("/opportunities")
    public List<Opportunity> getAllOpportunities() {
        log.debug("REST request to get all Opportunities");
        return opportunityRepository.findAll();
    }

    /**
     * {@code GET  /opportunities/:id} : get the "id" opportunity.
     *
     * @param id the id of the opportunity to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the opportunity, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/opportunities/{id}")
    public ResponseEntity<Opportunity> getOpportunity(@PathVariable Long id) {
        log.debug("REST request to get Opportunity : {}", id);
        Optional<Opportunity> opportunity = opportunityRepository.findById(id);
        if (opportunity.isPresent()) {
            Optional<List<QuestionAnswer>> questionAnswer = questionAnswerRepository.findByOpportunityId(id);
            if (questionAnswer.isPresent()) {
                opportunity.get().setQuestionAnswers(new HashSet(questionAnswer.get()));
            }

            // Optional<List<MoMs>> moMs = moMsRepository.findByOpportunityId(id);
            // if (moMs.isPresent()) {
            //     opportunity.get().setMoMs(new HashSet(moMs.get()));
            // }

        }
        return ResponseUtil.wrapOrNotFound(opportunity);
    }

    /**
     * {@code DELETE  /opportunities/:id} : delete the "id" opportunity.
     *
     * @param id the id of the opportunity to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/opportunities/{id}")
    public ResponseEntity<Void> deleteOpportunity(@PathVariable Long id) {
        log.debug("REST request to delete Opportunity : {}", id);
        opportunityRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}