/**
 * Spring Data JPA repositories.
 */
package com.amdocs.saleso.repository;
