package com.amdocs.saleso.domain;


import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

/**
 * A Opportunity.
 */
@Entity
@Table(name = "opportunity")
public class Opportunity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "opportunity_id")
    private String opportunityId;

    @Column(name = "account_name")
    private String accountName;

    @Column(name = "opportunity_name")
    private String opportunityName;

    @Column(name = "type")
    private String type;

    @Column(name = "opportunity_domain")
    private String opportunityDomain;

    @Column(name = "forecast_category")
    private String forecastCategory;

    @Column(name = "opportunity_stage")
    private String opportunityStage;

    @Column(name = "probability")
    private Double probability;

    @Column(name = "opportunity_size")
    private Double opportunitySize;

    @Column(name = "qualified_deal_size")
    private Double qualifiedDealSize;

    @Column(name = "weighted_deal_size")
    private Double weightedDealSize;

    @Column(name = "close_date")
    private Instant closeDate;

    @Column(name = "close_fiscal_quarter")
    private String closeFiscalQuarter;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "created_by")
    private Instant createdBy;

    @Column(name = "fops_names")
    private Instant fopsNames;

    @Column(name = "partners")
    private String partners;

    @Column(name = "competitors_names")
    private String competitorsNames;

    @Column(name = "opportunity_owner")
    private String opportunityOwner;

    @Column(name = "account_owner")
    private String accountOwner;

    @Column(name = "sccount_rvp")
    private String sccountRVP;

    @Column(name = "fiscal_year")
    private Integer fiscalYear;

    @Column(name = "qualified_win_loss")
    private Boolean qualifiedWinLoss;

    @Column(name = "opportunity_shadow_offerings")
    private String opportunityShadowOfferings;

    @OneToMany(mappedBy = "opportunity")
    private Set<MoMs> moMs = new HashSet<>();

    @OneToMany(mappedBy = "opportunity")
    private Set<QuestionAnswer> questionAnswers = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOpportunityId() {
        return opportunityId;
    }

    public Opportunity opportunityId(String opportunityId) {
        this.opportunityId = opportunityId;
        return this;
    }

    public void setOpportunityId(String opportunityId) {
        this.opportunityId = opportunityId;
    }

    public String getAccountName() {
        return accountName;
    }

    public Opportunity accountName(String accountName) {
        this.accountName = accountName;
        return this;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getOpportunityName() {
        return opportunityName;
    }

    public Opportunity opportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
        return this;
    }

    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    public String getType() {
        return type;
    }

    public Opportunity type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOpportunityDomain() {
        return opportunityDomain;
    }

    public Opportunity opportunityDomain(String opportunityDomain) {
        this.opportunityDomain = opportunityDomain;
        return this;
    }

    public void setOpportunityDomain(String opportunityDomain) {
        this.opportunityDomain = opportunityDomain;
    }

    public String getForecastCategory() {
        return forecastCategory;
    }

    public Opportunity forecastCategory(String forecastCategory) {
        this.forecastCategory = forecastCategory;
        return this;
    }

    public void setForecastCategory(String forecastCategory) {
        this.forecastCategory = forecastCategory;
    }

    public String getOpportunityStage() {
        return opportunityStage;
    }

    public Opportunity opportunityStage(String opportunityStage) {
        this.opportunityStage = opportunityStage;
        return this;
    }

    public void setOpportunityStage(String opportunityStage) {
        this.opportunityStage = opportunityStage;
    }

    public Double getProbability() {
        return probability;
    }

    public Opportunity probability(Double probability) {
        this.probability = probability;
        return this;
    }

    public void setProbability(Double probability) {
        this.probability = probability;
    }

    public Double getOpportunitySize() {
        return opportunitySize;
    }

    public Opportunity opportunitySize(Double opportunitySize) {
        this.opportunitySize = opportunitySize;
        return this;
    }

    public void setOpportunitySize(Double opportunitySize) {
        this.opportunitySize = opportunitySize;
    }

    public Double getQualifiedDealSize() {
        return qualifiedDealSize;
    }

    public Opportunity qualifiedDealSize(Double qualifiedDealSize) {
        this.qualifiedDealSize = qualifiedDealSize;
        return this;
    }

    public void setQualifiedDealSize(Double qualifiedDealSize) {
        this.qualifiedDealSize = qualifiedDealSize;
    }

    public Double getWeightedDealSize() {
        return weightedDealSize;
    }

    public Opportunity weightedDealSize(Double weightedDealSize) {
        this.weightedDealSize = weightedDealSize;
        return this;
    }

    public void setWeightedDealSize(Double weightedDealSize) {
        this.weightedDealSize = weightedDealSize;
    }

    public Instant getCloseDate() {
        return closeDate;
    }

    public Opportunity closeDate(Instant closeDate) {
        this.closeDate = closeDate;
        return this;
    }

    public void setCloseDate(Instant closeDate) {
        this.closeDate = closeDate;
    }

    public String getCloseFiscalQuarter() {
        return closeFiscalQuarter;
    }

    public Opportunity closeFiscalQuarter(String closeFiscalQuarter) {
        this.closeFiscalQuarter = closeFiscalQuarter;
        return this;
    }

    public void setCloseFiscalQuarter(String closeFiscalQuarter) {
        this.closeFiscalQuarter = closeFiscalQuarter;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public Opportunity createdDate(Instant createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public Instant getCreatedBy() {
        return createdBy;
    }

    public Opportunity createdBy(Instant createdBy) {
        this.createdBy = createdBy;
        return this;
    }

    public void setCreatedBy(Instant createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getFopsNames() {
        return fopsNames;
    }

    public Opportunity fopsNames(Instant fopsNames) {
        this.fopsNames = fopsNames;
        return this;
    }

    public void setFopsNames(Instant fopsNames) {
        this.fopsNames = fopsNames;
    }

    public String getPartners() {
        return partners;
    }

    public Opportunity partners(String partners) {
        this.partners = partners;
        return this;
    }

    public void setPartners(String partners) {
        this.partners = partners;
    }

    public String getCompetitorsNames() {
        return competitorsNames;
    }

    public Opportunity competitorsNames(String competitorsNames) {
        this.competitorsNames = competitorsNames;
        return this;
    }

    public void setCompetitorsNames(String competitorsNames) {
        this.competitorsNames = competitorsNames;
    }

    public String getOpportunityOwner() {
        return opportunityOwner;
    }

    public Opportunity opportunityOwner(String opportunityOwner) {
        this.opportunityOwner = opportunityOwner;
        return this;
    }

    public void setOpportunityOwner(String opportunityOwner) {
        this.opportunityOwner = opportunityOwner;
    }

    public String getAccountOwner() {
        return accountOwner;
    }

    public Opportunity accountOwner(String accountOwner) {
        this.accountOwner = accountOwner;
        return this;
    }

    public void setAccountOwner(String accountOwner) {
        this.accountOwner = accountOwner;
    }

    public String getSccountRVP() {
        return sccountRVP;
    }

    public Opportunity sccountRVP(String sccountRVP) {
        this.sccountRVP = sccountRVP;
        return this;
    }

    public void setSccountRVP(String sccountRVP) {
        this.sccountRVP = sccountRVP;
    }

    public Integer getFiscalYear() {
        return fiscalYear;
    }

    public Opportunity fiscalYear(Integer fiscalYear) {
        this.fiscalYear = fiscalYear;
        return this;
    }

    public void setFiscalYear(Integer fiscalYear) {
        this.fiscalYear = fiscalYear;
    }

    public Boolean isQualifiedWinLoss() {
        return qualifiedWinLoss;
    }

    public Opportunity qualifiedWinLoss(Boolean qualifiedWinLoss) {
        this.qualifiedWinLoss = qualifiedWinLoss;
        return this;
    }

    public void setQualifiedWinLoss(Boolean qualifiedWinLoss) {
        this.qualifiedWinLoss = qualifiedWinLoss;
    }

    public String getOpportunityShadowOfferings() {
        return opportunityShadowOfferings;
    }

    public Opportunity opportunityShadowOfferings(String opportunityShadowOfferings) {
        this.opportunityShadowOfferings = opportunityShadowOfferings;
        return this;
    }

    public void setOpportunityShadowOfferings(String opportunityShadowOfferings) {
        this.opportunityShadowOfferings = opportunityShadowOfferings;
    }

    public Set<MoMs> getMoMs() {
        return moMs;
    }

    public Opportunity moMs(Set<MoMs> moMs) {
        this.moMs = moMs;
        return this;
    }

    public Opportunity addMoMs(MoMs moMs) {
        this.moMs.add(moMs);
        moMs.setOpportunity(this);
        return this;
    }

    public Opportunity removeMoMs(MoMs moMs) {
        this.moMs.remove(moMs);
        moMs.setOpportunity(null);
        return this;
    }

    public void setMoMs(Set<MoMs> moMs) {
        this.moMs = moMs;
    }

    public Set<QuestionAnswer> getQuestionAnswers() {
        return questionAnswers;
    }

    public Opportunity questionAnswers(Set<QuestionAnswer> questionAnswers) {
        this.questionAnswers = questionAnswers;
        return this;
    }

    public Opportunity addQuestionAnswer(QuestionAnswer questionAnswer) {
        this.questionAnswers.add(questionAnswer);
        questionAnswer.setOpportunity(this);
        return this;
    }

    public Opportunity removeQuestionAnswer(QuestionAnswer questionAnswer) {
        this.questionAnswers.remove(questionAnswer);
        questionAnswer.setOpportunity(null);
        return this;
    }

    public void setQuestionAnswers(Set<QuestionAnswer> questionAnswers) {
        this.questionAnswers = questionAnswers;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Opportunity)) {
            return false;
        }
        return id != null && id.equals(((Opportunity) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Opportunity{" +
            "id=" + getId() +
            ", opportunityId='" + getOpportunityId() + "'" +
            ", accountName='" + getAccountName() + "'" +
            ", opportunityName='" + getOpportunityName() + "'" +
            ", type='" + getType() + "'" +
            ", opportunityDomain='" + getOpportunityDomain() + "'" +
            ", forecastCategory='" + getForecastCategory() + "'" +
            ", opportunityStage='" + getOpportunityStage() + "'" +
            ", probability=" + getProbability() +
            ", opportunitySize=" + getOpportunitySize() +
            ", qualifiedDealSize=" + getQualifiedDealSize() +
            ", weightedDealSize=" + getWeightedDealSize() +
            ", closeDate='" + getCloseDate() + "'" +
            ", closeFiscalQuarter='" + getCloseFiscalQuarter() + "'" +
            ", createdDate='" + getCreatedDate() + "'" +
            ", createdBy='" + getCreatedBy() + "'" +
            ", fopsNames='" + getFopsNames() + "'" +
            ", partners='" + getPartners() + "'" +
            ", competitorsNames='" + getCompetitorsNames() + "'" +
            ", opportunityOwner='" + getOpportunityOwner() + "'" +
            ", accountOwner='" + getAccountOwner() + "'" +
            ", sccountRVP='" + getSccountRVP() + "'" +
            ", fiscalYear=" + getFiscalYear() +
            ", qualifiedWinLoss='" + isQualifiedWinLoss() + "'" +
            ", opportunityShadowOfferings='" + getOpportunityShadowOfferings() + "'" +
            "}";
    }
}
