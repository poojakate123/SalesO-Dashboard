/**
 * Service layer beans.
 */
package com.amdocs.saleso.service;
