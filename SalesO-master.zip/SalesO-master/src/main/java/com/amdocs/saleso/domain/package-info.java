/**
 * JPA domain objects.
 */
package com.amdocs.saleso.domain;
