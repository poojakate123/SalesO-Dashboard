/**
 * Spring Security configuration.
 */
package com.amdocs.saleso.security;
