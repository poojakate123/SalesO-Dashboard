package com.amdocs.saleso.web.rest;

import com.amdocs.saleso.domain.MoMs;
import com.amdocs.saleso.repository.MoMsRepository;
import com.amdocs.saleso.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.amdocs.saleso.domain.MoMs}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class MoMsResource {

    private final Logger log = LoggerFactory.getLogger(MoMsResource.class);

    private static final String ENTITY_NAME = "moMs";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final MoMsRepository moMsRepository;

    public MoMsResource(MoMsRepository moMsRepository) {
        this.moMsRepository = moMsRepository;
    }

    /**
     * {@code POST  /mo-ms} : Create a new moMs.
     *
     * @param moMs the moMs to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new moMs, or with status {@code 400 (Bad Request)} if the moMs has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/mo-ms")
    public ResponseEntity<MoMs> createMoMs(@RequestBody MoMs moMs) throws URISyntaxException {
        log.debug("REST request to save MoMs : {}", moMs);
        if (moMs.getId() != null) {
            throw new BadRequestAlertException("A new moMs cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MoMs result = moMsRepository.save(moMs);
        return ResponseEntity.created(new URI("/api/mo-ms/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /mo-ms} : Updates an existing moMs.
     *
     * @param moMs the moMs to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated moMs,
     * or with status {@code 400 (Bad Request)} if the moMs is not valid,
     * or with status {@code 500 (Internal Server Error)} if the moMs couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/mo-ms")
    public ResponseEntity<MoMs> updateMoMs(@RequestBody MoMs moMs) throws URISyntaxException {
        log.debug("REST request to update MoMs : {}", moMs);
        if (moMs.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MoMs result = moMsRepository.save(moMs);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, moMs.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /mo-ms} : get all the moMs.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of moMs in body.
     */
    @GetMapping("/mo-ms")
    public List<MoMs> getAllMoMs() {
        log.debug("REST request to get all MoMs");
        return moMsRepository.findAll();
    }

    /**
     * {@code GET  /mo-ms/:id} : get the "id" moMs.
     *
     * @param id the id of the moMs to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the moMs, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/mo-ms/{id}")
    public ResponseEntity<MoMs> getMoMs(@PathVariable Long id) {
        log.debug("REST request to get MoMs : {}", id);
        Optional<MoMs> moMs = moMsRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(moMs);
    }

    /**
     * {@code DELETE  /mo-ms/:id} : delete the "id" moMs.
     *
     * @param id the id of the moMs to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/mo-ms/{id}")
    public ResponseEntity<Void> deleteMoMs(@PathVariable Long id) {
        log.debug("REST request to delete MoMs : {}", id);
        moMsRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
