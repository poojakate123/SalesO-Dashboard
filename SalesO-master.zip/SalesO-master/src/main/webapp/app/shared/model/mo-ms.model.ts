import { Moment } from 'moment';
import { IOpportunity } from 'app/shared/model/opportunity.model';

export interface IMoMs {
  id?: number;
  title?: string;
  description?: string;
  date?: Moment;
  isPositive?: boolean;
  concern?: string;
  probability?: number;
  opportunity?: IOpportunity;
}

export class MoMs implements IMoMs {
  constructor(
    public id?: number,
    public title?: string,
    public description?: string,
    public date?: Moment,
    public isPositive?: boolean,
    public concern?: string,
    public probability?: number,
    public opportunity?: IOpportunity
  ) {
    this.isPositive = this.isPositive || false;
  }
}
