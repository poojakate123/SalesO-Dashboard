import { IOpportunity } from 'app/shared/model/opportunity.model';

export interface IQuestionAnswer {
  id?: number;
  question?: string;
  answer?: string;
  opportunity?: IOpportunity;
}

export class QuestionAnswer implements IQuestionAnswer {
  constructor(public id?: number, public question?: string, public answer?: string, public opportunity?: IOpportunity) {}
}
