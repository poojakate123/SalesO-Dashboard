import { Moment } from 'moment';
import { IMoMs } from 'app/shared/model/mo-ms.model';
import { IQuestionAnswer } from 'app/shared/model/question-answer.model';

export interface IOpportunity {
  id?: number;
  opportunityId?: string;
  accountName?: string;
  opportunityName?: string;
  type?: string;
  opportunityDomain?: string;
  forecastCategory?: string;
  opportunityStage?: string;
  probability?: number;
  opportunitySize?: number;
  qualifiedDealSize?: number;
  weightedDealSize?: number;
  closeDate?: Moment;
  closeFiscalQuarter?: string;
  createdDate?: Moment;
  createdBy?: Moment;
  fopsNames?: Moment;
  partners?: string;
  competitorsNames?: string;
  opportunityOwner?: string;
  accountOwner?: string;
  sccountRVP?: string;
  fiscalYear?: number;
  qualifiedWinLoss?: boolean;
  opportunityShadowOfferings?: string;
  moMs?: IMoMs[];
  questionAnswers?: IQuestionAnswer[];
}

export class Opportunity implements IOpportunity {
  constructor(
    public id?: number,
    public opportunityId?: string,
    public accountName?: string,
    public opportunityName?: string,
    public type?: string,
    public opportunityDomain?: string,
    public forecastCategory?: string,
    public opportunityStage?: string,
    public probability?: number,
    public opportunitySize?: number,
    public qualifiedDealSize?: number,
    public weightedDealSize?: number,
    public closeDate?: Moment,
    public closeFiscalQuarter?: string,
    public createdDate?: Moment,
    public createdBy?: Moment,
    public fopsNames?: Moment,
    public partners?: string,
    public competitorsNames?: string,
    public opportunityOwner?: string,
    public accountOwner?: string,
    public sccountRVP?: string,
    public fiscalYear?: number,
    public qualifiedWinLoss?: boolean,
    public opportunityShadowOfferings?: string,
    public moMs?: IMoMs[],
    public questionAnswers?: IQuestionAnswer[]
  ) {
    this.qualifiedWinLoss = this.qualifiedWinLoss || false;
  }
}
