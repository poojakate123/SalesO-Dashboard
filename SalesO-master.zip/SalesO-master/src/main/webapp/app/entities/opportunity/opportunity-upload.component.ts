import { HttpResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { IOpportunity, Opportunity } from 'app/shared/model/opportunity.model';
import { NgxCsvParser, NgxCSVParserError } from 'ngx-csv-parser';
import { OpportunityService } from './opportunity.service';

/* eslint-disable */

@Component({
  selector: 'jhi-opportunity-upload',
  templateUrl: './opportunity-upload.component.html',
  styleUrls: ['./opportunity-upload.component.scss']
})
export class OpportunityUploadComponent implements OnInit {
  csvRecords: any[] = [];
  @ViewChild('fileImportInput', { static: false }) fileImportInput: any;
  opportunityData: Array<Opportunity> = [];
  savedOpportunities: any;

  constructor(private ngxCsvParser: NgxCsvParser, private opportunityService: OpportunityService) {}

  ngOnInit(): void {}

  // Your applications input change listener for the CSV File
  fileChangeListener($event: any): void {
    // Select the files from the event
    const files = $event.srcElement.files;

    // Parse the file you want to select for the operation along with the configuration
    this.ngxCsvParser
      .parse(files[0], { header: true, delimiter: ',' })
      .pipe()
      .subscribe(
        (res: any) => {
          this.csvRecords = res;

          const result = res as Array<any>;
          this.opportunityData = [];

          if (result && result.length) {
            result.forEach(oppo => {
              if (oppo.ID && /Opp - [0-9]/.test(oppo.ID)) {
                const opportunity: Opportunity = {};
                opportunity.opportunityId = oppo['ID'];
                opportunity.accountName = oppo['Account Name'];
                opportunity.opportunityName = oppo['Opportunity Name'];
                opportunity.type = oppo['Type'];
                opportunity.opportunityDomain = oppo['Opportunity Domain'];
                opportunity.forecastCategory = oppo['Forecast Category'];
                opportunity.opportunityStage = oppo['Opportunity Stage'];
                opportunity.probability = +oppo['Probability (%)'];
                opportunity.opportunitySize = +oppo['Opportunity Size (in K)'];
                opportunity.qualifiedDealSize = +oppo['Qualified Deal Size'];
                opportunity.weightedDealSize = +oppo['Weighted Deal Size'];
                opportunity.closeDate = undefined; // oppo["Close Date"];
                opportunity.closeFiscalQuarter = oppo['Close Fiscal Quarter'];
                opportunity.createdDate = undefined; // oppo["Created Date"];
                opportunity.createdBy = undefined; //oppo["Created By"];
                opportunity.fopsNames = undefined; //oppo["Fops'Names"];
                opportunity.partners = oppo['Partners'];
                opportunity.competitorsNames = oppo["Competitors'Names"];
                opportunity.opportunityOwner = oppo['Opportunity Owner'];
                opportunity.accountOwner = oppo['Account Owner'];
                opportunity.sccountRVP = oppo['Account RVP'];
                opportunity.fiscalYear = +oppo['Fiscal Year'];
                opportunity.opportunityShadowOfferings = oppo['Opportunity Shadow Offerings'];
                opportunity.qualifiedWinLoss = (oppo['Qualified Win Loss'] || '').toLowerCase().trim() === 'true';
                this.opportunityData.push(opportunity);
              }
            });
          }

          if (this.opportunityData && this.opportunityData.length) {
            this.opportunityService
              .createMany(this.opportunityData)
              .subscribe((res: HttpResponse<IOpportunity[]>) => (this.savedOpportunities = res.body || []));
          }

          console.log('opportunityData = ', this.opportunityData);
        },
        (error: NgxCSVParserError) => {
          console.log('Error', error);
        }
      );
  }
}
