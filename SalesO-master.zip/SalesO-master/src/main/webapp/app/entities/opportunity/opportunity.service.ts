import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared/util/request-util';
import { IOpportunity } from 'app/shared/model/opportunity.model';

type EntityResponseType = HttpResponse<IOpportunity>;
type EntityArrayResponseType = HttpResponse<IOpportunity[]>;

@Injectable({ providedIn: 'root' })
export class OpportunityService {
  public resourceUrl = SERVER_API_URL + 'api/opportunities';

  constructor(protected http: HttpClient) {}

  create(opportunity: IOpportunity): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(opportunity);
    return this.http
      .post<IOpportunity>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  createMany(opportunities: Array<IOpportunity>): Observable<EntityArrayResponseType> {
    const copy = opportunities.map(this.convertDateFromClient);
    return this.http
      .post<IOpportunity[]>(`${this.resourceUrl}/save-many`, copy, { observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));

    // .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(opportunity: IOpportunity): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(opportunity);
    return this.http
      .put<IOpportunity>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IOpportunity>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IOpportunity[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  protected convertDateFromClient(opportunity: IOpportunity): IOpportunity {
    const copy: IOpportunity = Object.assign({}, opportunity, {
      closeDate: opportunity.closeDate && opportunity.closeDate.isValid() ? opportunity.closeDate.toJSON() : undefined,
      createdDate: opportunity.createdDate && opportunity.createdDate.isValid() ? opportunity.createdDate.toJSON() : undefined,
      createdBy: opportunity.createdBy && opportunity.createdBy.isValid() ? opportunity.createdBy.toJSON() : undefined,
      fopsNames: opportunity.fopsNames && opportunity.fopsNames.isValid() ? opportunity.fopsNames.toJSON() : undefined
    });
    return copy;
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.closeDate = res.body.closeDate ? moment(res.body.closeDate) : undefined;
      res.body.createdDate = res.body.createdDate ? moment(res.body.createdDate) : undefined;
      res.body.createdBy = res.body.createdBy ? moment(res.body.createdBy) : undefined;
      res.body.fopsNames = res.body.fopsNames ? moment(res.body.fopsNames) : undefined;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((opportunity: IOpportunity) => {
        opportunity.closeDate = opportunity.closeDate ? moment(opportunity.closeDate) : undefined;
        opportunity.createdDate = opportunity.createdDate ? moment(opportunity.createdDate) : undefined;
        opportunity.createdBy = opportunity.createdBy ? moment(opportunity.createdBy) : undefined;
        opportunity.fopsNames = opportunity.fopsNames ? moment(opportunity.fopsNames) : undefined;
      });
    }
    return res;
  }
}
