import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { IOpportunity, Opportunity } from 'app/shared/model/opportunity.model';
import { OpportunityService } from './opportunity.service';

@Component({
  selector: 'jhi-opportunity-update',
  templateUrl: './opportunity-update.component.html'
})
export class OpportunityUpdateComponent implements OnInit {
  isSaving = false;

  editForm = this.fb.group({
    id: [],
    opportunityId: [],
    accountName: [],
    opportunityName: [],
    type: [],
    opportunityDomain: [],
    forecastCategory: [],
    opportunityStage: [],
    probability: [],
    opportunitySize: [],
    qualifiedDealSize: [],
    weightedDealSize: [],
    closeDate: [],
    closeFiscalQuarter: [],
    createdDate: [],
    createdBy: [],
    fopsNames: [],
    partners: [],
    competitorsNames: [],
    opportunityOwner: [],
    accountOwner: [],
    sccountRVP: [],
    fiscalYear: [],
    qualifiedWinLoss: [],
    opportunityShadowOfferings: []
  });

  constructor(protected opportunityService: OpportunityService, protected activatedRoute: ActivatedRoute, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ opportunity }) => {
      if (!opportunity.id) {
        const today = moment().startOf('day');
        opportunity.closeDate = today;
        opportunity.createdDate = today;
        opportunity.createdBy = today;
        opportunity.fopsNames = today;
      }

      this.updateForm(opportunity);
    });
  }

  updateForm(opportunity: IOpportunity): void {
    this.editForm.patchValue({
      id: opportunity.id,
      opportunityId: opportunity.opportunityId,
      accountName: opportunity.accountName,
      opportunityName: opportunity.opportunityName,
      type: opportunity.type,
      opportunityDomain: opportunity.opportunityDomain,
      forecastCategory: opportunity.forecastCategory,
      opportunityStage: opportunity.opportunityStage,
      probability: opportunity.probability,
      opportunitySize: opportunity.opportunitySize,
      qualifiedDealSize: opportunity.qualifiedDealSize,
      weightedDealSize: opportunity.weightedDealSize,
      closeDate: opportunity.closeDate ? opportunity.closeDate.format(DATE_TIME_FORMAT) : null,
      closeFiscalQuarter: opportunity.closeFiscalQuarter,
      createdDate: opportunity.createdDate ? opportunity.createdDate.format(DATE_TIME_FORMAT) : null,
      createdBy: opportunity.createdBy ? opportunity.createdBy.format(DATE_TIME_FORMAT) : null,
      fopsNames: opportunity.fopsNames ? opportunity.fopsNames.format(DATE_TIME_FORMAT) : null,
      partners: opportunity.partners,
      competitorsNames: opportunity.competitorsNames,
      opportunityOwner: opportunity.opportunityOwner,
      accountOwner: opportunity.accountOwner,
      sccountRVP: opportunity.sccountRVP,
      fiscalYear: opportunity.fiscalYear,
      qualifiedWinLoss: opportunity.qualifiedWinLoss,
      opportunityShadowOfferings: opportunity.opportunityShadowOfferings
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const opportunity = this.createFromForm();
    if (opportunity.id !== undefined) {
      this.subscribeToSaveResponse(this.opportunityService.update(opportunity));
    } else {
      this.subscribeToSaveResponse(this.opportunityService.create(opportunity));
    }
  }

  private createFromForm(): IOpportunity {
    return {
      ...new Opportunity(),
      id: this.editForm.get(['id'])!.value,
      opportunityId: this.editForm.get(['opportunityId'])!.value,
      accountName: this.editForm.get(['accountName'])!.value,
      opportunityName: this.editForm.get(['opportunityName'])!.value,
      type: this.editForm.get(['type'])!.value,
      opportunityDomain: this.editForm.get(['opportunityDomain'])!.value,
      forecastCategory: this.editForm.get(['forecastCategory'])!.value,
      opportunityStage: this.editForm.get(['opportunityStage'])!.value,
      probability: this.editForm.get(['probability'])!.value,
      opportunitySize: this.editForm.get(['opportunitySize'])!.value,
      qualifiedDealSize: this.editForm.get(['qualifiedDealSize'])!.value,
      weightedDealSize: this.editForm.get(['weightedDealSize'])!.value,
      closeDate: this.editForm.get(['closeDate'])!.value ? moment(this.editForm.get(['closeDate'])!.value, DATE_TIME_FORMAT) : undefined,
      closeFiscalQuarter: this.editForm.get(['closeFiscalQuarter'])!.value,
      createdDate: this.editForm.get(['createdDate'])!.value
        ? moment(this.editForm.get(['createdDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      createdBy: this.editForm.get(['createdBy'])!.value ? moment(this.editForm.get(['createdBy'])!.value, DATE_TIME_FORMAT) : undefined,
      fopsNames: this.editForm.get(['fopsNames'])!.value ? moment(this.editForm.get(['fopsNames'])!.value, DATE_TIME_FORMAT) : undefined,
      partners: this.editForm.get(['partners'])!.value,
      competitorsNames: this.editForm.get(['competitorsNames'])!.value,
      opportunityOwner: this.editForm.get(['opportunityOwner'])!.value,
      accountOwner: this.editForm.get(['accountOwner'])!.value,
      sccountRVP: this.editForm.get(['sccountRVP'])!.value,
      fiscalYear: this.editForm.get(['fiscalYear'])!.value,
      qualifiedWinLoss: this.editForm.get(['qualifiedWinLoss'])!.value,
      opportunityShadowOfferings: this.editForm.get(['opportunityShadowOfferings'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IOpportunity>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }
}
