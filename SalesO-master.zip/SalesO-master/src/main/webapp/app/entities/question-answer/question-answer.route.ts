import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { IQuestionAnswer, QuestionAnswer } from 'app/shared/model/question-answer.model';
import { QuestionAnswerService } from './question-answer.service';
import { QuestionAnswerComponent } from './question-answer.component';
import { QuestionAnswerDetailComponent } from './question-answer-detail.component';
import { QuestionAnswerUpdateComponent } from './question-answer-update.component';

@Injectable({ providedIn: 'root' })
export class QuestionAnswerResolve implements Resolve<IQuestionAnswer> {
  constructor(private service: QuestionAnswerService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IQuestionAnswer> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((questionAnswer: HttpResponse<QuestionAnswer>) => {
          if (questionAnswer.body) {
            return of(questionAnswer.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new QuestionAnswer());
  }
}

export const questionAnswerRoute: Routes = [
  {
    path: '',
    component: QuestionAnswerComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'QuestionAnswers'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: QuestionAnswerDetailComponent,
    resolve: {
      questionAnswer: QuestionAnswerResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'QuestionAnswers'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: QuestionAnswerUpdateComponent,
    resolve: {
      questionAnswer: QuestionAnswerResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'QuestionAnswers'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: QuestionAnswerUpdateComponent,
    resolve: {
      questionAnswer: QuestionAnswerResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'QuestionAnswers'
    },
    canActivate: [UserRouteAccessService]
  }
];
