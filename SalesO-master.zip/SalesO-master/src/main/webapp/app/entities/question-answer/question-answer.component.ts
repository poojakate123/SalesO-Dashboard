import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { IQuestionAnswer } from 'app/shared/model/question-answer.model';
import { QuestionAnswerService } from './question-answer.service';
import { QuestionAnswerDeleteDialogComponent } from './question-answer-delete-dialog.component';

@Component({
  selector: 'jhi-question-answer',
  templateUrl: './question-answer.component.html'
})
export class QuestionAnswerComponent implements OnInit, OnDestroy {
  questionAnswers?: IQuestionAnswer[];
  eventSubscriber?: Subscription;

  constructor(
    protected questionAnswerService: QuestionAnswerService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal
  ) {}

  loadAll(): void {
    this.questionAnswerService.query().subscribe((res: HttpResponse<IQuestionAnswer[]>) => (this.questionAnswers = res.body || []));
  }

  ngOnInit(): void {
    this.loadAll();
    this.registerChangeInQuestionAnswers();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: IQuestionAnswer): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInQuestionAnswers(): void {
    this.eventSubscriber = this.eventManager.subscribe('questionAnswerListModification', () => this.loadAll());
  }

  delete(questionAnswer: IQuestionAnswer): void {
    const modalRef = this.modalService.open(QuestionAnswerDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.questionAnswer = questionAnswer;
  }
}
