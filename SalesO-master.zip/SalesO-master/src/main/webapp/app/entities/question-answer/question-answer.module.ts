import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SalesOSharedModule } from 'app/shared/shared.module';
import { QuestionAnswerComponent } from './question-answer.component';
import { QuestionAnswerDetailComponent } from './question-answer-detail.component';
import { QuestionAnswerUpdateComponent } from './question-answer-update.component';
import { QuestionAnswerDeleteDialogComponent } from './question-answer-delete-dialog.component';
import { questionAnswerRoute } from './question-answer.route';

@NgModule({
  imports: [SalesOSharedModule, RouterModule.forChild(questionAnswerRoute)],
  declarations: [
    QuestionAnswerComponent,
    QuestionAnswerDetailComponent,
    QuestionAnswerUpdateComponent,
    QuestionAnswerDeleteDialogComponent
  ],
  entryComponents: [QuestionAnswerDeleteDialogComponent]
})
export class SalesOQuestionAnswerModule {}
