import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IQuestionAnswer, QuestionAnswer } from 'app/shared/model/question-answer.model';
import { QuestionAnswerService } from './question-answer.service';
import { IOpportunity } from 'app/shared/model/opportunity.model';
import { OpportunityService } from 'app/entities/opportunity/opportunity.service';

/* eslint-disable */
@Component({
  selector: 'jhi-question-answer-update',
  templateUrl: './question-answer-update.component.html'
})
export class QuestionAnswerUpdateComponent implements OnInit {
  isSaving = false;
  opportunities: IOpportunity[] = [];
  selectedOpportunity: IOpportunity = {};

  editForm = this.fb.group({
    id: [],
    question: [],
    answer: [],
    opportunity: []
  });

  constructor(
    protected questionAnswerService: QuestionAnswerService,
    protected opportunityService: OpportunityService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ questionAnswer }) => {
      this.updateForm(questionAnswer);

      this.opportunityService.query().subscribe((res: HttpResponse<IOpportunity[]>) => (this.opportunities = res.body || []));
    });
  }

  //////////////////////////////////////////

  saveQuestions() {
    const questionAnswers: Array<IQuestionAnswer> = [];

    this.sampleQa.forEach(filledQa => {
      const qa: IQuestionAnswer = {};
      qa.opportunity = this.selectedOpportunity;
      qa.question = filledQa.question;
      qa.answer = filledQa.answer;
      questionAnswers.push(qa);
    });

    this.subscribeToSaveManyResponse(this.questionAnswerService.createMany(questionAnswers));
  }

  //////////////////////////////////////////

  updateForm(questionAnswer: IQuestionAnswer): void {
    this.editForm.patchValue({
      id: questionAnswer.id,
      question: questionAnswer.question,
      answer: questionAnswer.answer,
      opportunity: questionAnswer.opportunity
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const questionAnswer = this.createFromForm();
    if (questionAnswer.id !== undefined) {
      this.subscribeToSaveResponse(this.questionAnswerService.update(questionAnswer));
    } else {
      this.subscribeToSaveResponse(this.questionAnswerService.create(questionAnswer));
    }
  }

  private createFromForm(): IQuestionAnswer {
    return {
      ...new QuestionAnswer(),
      id: this.editForm.get(['id'])!.value,
      question: this.editForm.get(['question'])!.value,
      answer: this.editForm.get(['answer'])!.value,
      opportunity: this.editForm.get(['opportunity'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IQuestionAnswer>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected subscribeToSaveManyResponse(result: Observable<HttpResponse<IQuestionAnswer[]>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: IOpportunity): any {
    return item.id;
  }

  sampleQa: Array<any> = [
    {
      question: 'What according to you as a sales person could be the reason for losing the deal?'
    },
    {
      question: 'What comments the client gave before rejecting the offer? ',
      placeholder: 'examples - amdocs is expensive, im not happy with services offered, i have another alternative offer'
    },
    {
      question: 'Did the client mention about any other competitor while closing the deal?',
      placeholder: 'Example: I am chosing accenture as they have better plans'
    },
    {
      question: 'Did the client mention about any other technology that they wish to move to in future?',
      placeholder: 'Example: The client said i will invest in blockchain now instead of 5G'
    },
    {
      question: 'Were we ( Amdocs) were in position to give counter offer ?',
      placeholder: 'Example: If client rejected can amdocs convince them by some other service, offer'
    },
    {
      question:
        'Do you think this reason of losing could impact any other opportunities in pipeline? If yes mention the opportunity name and id below',
      placeholder: 'Example: yes this may have an impact on xyz opportunityid -123'
    },
    {
      question: 'Provide your final comments and feedback (Sales exe)?'
    }
  ];
}
