import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IQuestionAnswer } from 'app/shared/model/question-answer.model';
import { QuestionAnswerService } from './question-answer.service';

@Component({
  templateUrl: './question-answer-delete-dialog.component.html'
})
export class QuestionAnswerDeleteDialogComponent {
  questionAnswer?: IQuestionAnswer;

  constructor(
    protected questionAnswerService: QuestionAnswerService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.questionAnswerService.delete(id).subscribe(() => {
      this.eventManager.broadcast('questionAnswerListModification');
      this.activeModal.close();
    });
  }
}
