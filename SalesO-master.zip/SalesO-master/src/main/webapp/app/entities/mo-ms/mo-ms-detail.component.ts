import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IMoMs } from 'app/shared/model/mo-ms.model';

@Component({
  selector: 'jhi-mo-ms-detail',
  templateUrl: './mo-ms-detail.component.html'
})
export class MoMsDetailComponent implements OnInit {
  moMs: IMoMs | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ moMs }) => (this.moMs = moMs));
  }

  previousState(): void {
    window.history.back();
  }
}
