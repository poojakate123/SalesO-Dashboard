import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { IMoMs } from 'app/shared/model/mo-ms.model';
import { MoMsService } from './mo-ms.service';
import { MoMsDeleteDialogComponent } from './mo-ms-delete-dialog.component';

@Component({
  selector: 'jhi-mo-ms',
  templateUrl: './mo-ms.component.html'
})
export class MoMsComponent implements OnInit, OnDestroy {
  moMs?: IMoMs[];
  eventSubscriber?: Subscription;

  constructor(protected moMsService: MoMsService, protected eventManager: JhiEventManager, protected modalService: NgbModal) {}

  loadAll(): void {
    this.moMsService.query().subscribe((res: HttpResponse<IMoMs[]>) => (this.moMs = res.body || []));
  }

  ngOnInit(): void {
    this.loadAll();
    this.registerChangeInMoMs();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: IMoMs): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInMoMs(): void {
    this.eventSubscriber = this.eventManager.subscribe('moMsListModification', () => this.loadAll());
  }

  delete(moMs: IMoMs): void {
    const modalRef = this.modalService.open(MoMsDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.moMs = moMs;
  }
}
