import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { IMoMs, MoMs } from 'app/shared/model/mo-ms.model';
import { MoMsService } from './mo-ms.service';
import { MoMsComponent } from './mo-ms.component';
import { MoMsDetailComponent } from './mo-ms-detail.component';
import { MoMsUpdateComponent } from './mo-ms-update.component';

@Injectable({ providedIn: 'root' })
export class MoMsResolve implements Resolve<IMoMs> {
  constructor(private service: MoMsService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IMoMs> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((moMs: HttpResponse<MoMs>) => {
          if (moMs.body) {
            return of(moMs.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new MoMs());
  }
}

export const moMsRoute: Routes = [
  {
    path: '',
    component: MoMsComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'MoMs'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: MoMsDetailComponent,
    resolve: {
      moMs: MoMsResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'MoMs'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: MoMsUpdateComponent,
    resolve: {
      moMs: MoMsResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'MoMs'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: MoMsUpdateComponent,
    resolve: {
      moMs: MoMsResolve
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'MoMs'
    },
    canActivate: [UserRouteAccessService]
  }
];
