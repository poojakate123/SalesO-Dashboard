import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { IMoMs, MoMs } from 'app/shared/model/mo-ms.model';
import { MoMsService } from './mo-ms.service';
import { IOpportunity } from 'app/shared/model/opportunity.model';
import { OpportunityService } from 'app/entities/opportunity/opportunity.service';

@Component({
  selector: 'jhi-mo-ms-update',
  templateUrl: './mo-ms-update.component.html'
})
export class MoMsUpdateComponent implements OnInit {
  isSaving = false;
  opportunities: IOpportunity[] = [];

  editForm = this.fb.group({
    id: [],
    title: [],
    description: [],
    date: [],
    isPositive: [],
    concern: [],
    probability: [],
    opportunity: []
  });

  constructor(
    protected moMsService: MoMsService,
    protected opportunityService: OpportunityService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ moMs }) => {
      if (!moMs.id) {
        const today = moment().startOf('day');
        moMs.date = today;
      }

      this.updateForm(moMs);

      this.opportunityService.query().subscribe((res: HttpResponse<IOpportunity[]>) => (this.opportunities = res.body || []));
    });
  }

  updateForm(moMs: IMoMs): void {
    this.editForm.patchValue({
      id: moMs.id,
      title: moMs.title,
      description: moMs.description,
      date: moMs.date ? moMs.date.format(DATE_TIME_FORMAT) : null,
      isPositive: moMs.isPositive,
      concern: moMs.concern,
      probability: moMs.probability,
      opportunity: moMs.opportunity
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const moMs = this.createFromForm();
    if (moMs.id !== undefined) {
      this.subscribeToSaveResponse(this.moMsService.update(moMs));
    } else {
      this.subscribeToSaveResponse(this.moMsService.create(moMs));
    }
  }

  private createFromForm(): IMoMs {
    return {
      ...new MoMs(),
      id: this.editForm.get(['id'])!.value,
      title: this.editForm.get(['title'])!.value,
      description: this.editForm.get(['description'])!.value,
      date: this.editForm.get(['date'])!.value ? moment(this.editForm.get(['date'])!.value, DATE_TIME_FORMAT) : undefined,
      isPositive: this.editForm.get(['isPositive'])!.value,
      concern: this.editForm.get(['concern'])!.value,
      probability: this.editForm.get(['probability'])!.value,
      opportunity: this.editForm.get(['opportunity'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IMoMs>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: IOpportunity): any {
    return item.id;
  }
}
