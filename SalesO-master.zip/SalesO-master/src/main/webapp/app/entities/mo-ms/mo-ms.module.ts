import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SalesOSharedModule } from 'app/shared/shared.module';
import { MoMsComponent } from './mo-ms.component';
import { MoMsDetailComponent } from './mo-ms-detail.component';
import { MoMsUpdateComponent } from './mo-ms-update.component';
import { MoMsDeleteDialogComponent } from './mo-ms-delete-dialog.component';
import { moMsRoute } from './mo-ms.route';

@NgModule({
  imports: [SalesOSharedModule, RouterModule.forChild(moMsRoute)],
  declarations: [MoMsComponent, MoMsDetailComponent, MoMsUpdateComponent, MoMsDeleteDialogComponent],
  entryComponents: [MoMsDeleteDialogComponent]
})
export class SalesOMoMsModule {}
