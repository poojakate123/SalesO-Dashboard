import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared/util/request-util';
import { IMoMs } from 'app/shared/model/mo-ms.model';

type EntityResponseType = HttpResponse<IMoMs>;
type EntityArrayResponseType = HttpResponse<IMoMs[]>;

@Injectable({ providedIn: 'root' })
export class MoMsService {
  public resourceUrl = SERVER_API_URL + 'api/mo-ms';

  constructor(protected http: HttpClient) {}

  create(moMs: IMoMs): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(moMs);
    return this.http
      .post<IMoMs>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(moMs: IMoMs): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(moMs);
    return this.http
      .put<IMoMs>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IMoMs>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IMoMs[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  protected convertDateFromClient(moMs: IMoMs): IMoMs {
    const copy: IMoMs = Object.assign({}, moMs, {
      date: moMs.date && moMs.date.isValid() ? moMs.date.toJSON() : undefined
    });
    return copy;
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.date = res.body.date ? moment(res.body.date) : undefined;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((moMs: IMoMs) => {
        moMs.date = moMs.date ? moment(moMs.date) : undefined;
      });
    }
    return res;
  }
}
