import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IMoMs } from 'app/shared/model/mo-ms.model';
import { MoMsService } from './mo-ms.service';

@Component({
  templateUrl: './mo-ms-delete-dialog.component.html'
})
export class MoMsDeleteDialogComponent {
  moMs?: IMoMs;

  constructor(protected moMsService: MoMsService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.moMsService.delete(id).subscribe(() => {
      this.eventManager.broadcast('moMsListModification');
      this.activeModal.close();
    });
  }
}
