import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'opportunity',
        loadChildren: () => import('./opportunity/opportunity.module').then(m => m.SalesOOpportunityModule)
      },
      {
        path: 'question-answer',
        loadChildren: () => import('./question-answer/question-answer.module').then(m => m.SalesOQuestionAnswerModule)
      },
      {
        path: 'mo-ms',
        loadChildren: () => import('./mo-ms/mo-ms.module').then(m => m.SalesOMoMsModule)
      }
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ])
  ]
})
export class SalesOEntityModule {}
